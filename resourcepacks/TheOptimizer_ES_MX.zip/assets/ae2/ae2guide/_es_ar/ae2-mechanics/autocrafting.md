---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Autocrafteo
  icon: pattern_provider
---

# Autocrafteo

### El gran tema

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

El autocrafteo es una de las funciones principales de AE2. En vez de calcular a mano cuántos componentes necesitas y trabajar como un *plebeyo*, puedes pedírselo a tu sistema ME. También puedes craftear objetos automáticamente y exportarlos, o mantener ciertas cantidades en reserva aprovechando cómo interactúan sus componentes. Funciona con fluidos y, con los complementos adecuados, con materiales de otros mods, como los gases de Mekanism. Una maravilla.

Es un tema complejo, así que abróchate el cinturón y vamos allá.

Una instalación de autocrafteo consta de 3 elementos:
- El componente que solicita el crafteo.
- La CPU de crafteo.
- El <ItemLink id="pattern_provider" />.

Esto es lo que sucede:

1. Algo crea una solicitud de crafteo. Puedes ser tú al seleccionar en la terminal algo que se pueda autocraftear, o un bus de exportación o una interfaz con una tarjeta de crafteo que solicita uno de los objetos configurados para exportar o mantener en reserva.

* **IMPORTANTE:** para solicitar el crafteo de algo que ya tienes almacenado, usa la tecla asignada a «Seleccionar bloque», normalmente el click central. Puede entrar en conflicto con los mods que ordenan el inventario.

2. El sistema ME calcula los ingredientes y pasos previos necesarios para completar la solicitud y los guarda en la CPU de crafteo seleccionada.

3. El <ItemLink id="pattern_provider" /> que contiene el [patrón](../items-blocks-machines/patterns.md) correspondiente envía los ingredientes indicados a un inventario adyacente. Para una receta de mesa de crafteo, un «patrón de crafteo», será un <ItemLink id="molecular_assembler" />. Para una receta de otro tipo, un «patrón de procesamiento», será otro bloque, una máquina o una instalación elaborada controlada con redstone.

4. El resultado regresa al sistema mediante un bus de importación, una interfaz o insertándolo de nuevo en un proveedor de patrones. **Debe producirse una entrada de objetos al sistema: no basta con enviar el resultado por una tubería a un cofre conectado a un <ItemLink id="storage_bus" />.**

5. Si ese crafteo es un paso previo de otro dentro de la solicitud, los objetos se guardan en esa CPU de crafteo y se usan en el siguiente paso.

# Patrones

<ItemImage id="crafting_pattern" scale="4" />

Los patrones se crean en una <ItemLink id="pattern_encoding_terminal" /> a partir de patrones en blanco.

Hay varios tipos de patrones para distintas operaciones:

* Los <ItemLink id="crafting_pattern" /> codifican recetas de mesa de crafteo. Puedes introducir uno directamente en un <ItemLink id="molecular_assembler" /> para que craftee el resultado al recibir los ingredientes, pero su uso principal es en un <ItemLink id="pattern_provider" /> junto a un ensamblador molecular. En ese caso, el proveedor envía tanto los ingredientes como el patrón a los ensambladores adyacentes. Estos expulsan automáticamente los resultados a inventarios adyacentes, así que basta con un ensamblador junto a un proveedor para automatizar los patrones de crafteo.

***

* Los <ItemLink id="smithing_table_pattern" /> son muy parecidos a los patrones de crafteo, pero codifican recetas de mesa de herrería. También se automatizan con un proveedor de patrones y un ensamblador molecular, y funcionan igual. De hecho, puedes usar patrones de crafteo, herrería y cortapiedras en la misma instalación.

***

* Los <ItemLink id="stonecutting_pattern" /> son muy parecidos a los patrones de crafteo, pero codifican recetas de cortapiedras. También se automatizan con un proveedor de patrones y un ensamblador molecular, y funcionan igual. De hecho, puedes usar patrones de crafteo, herrería y cortapiedras en la misma instalación.

***

* Los <ItemLink id="processing_pattern" /> aportan gran parte de la flexibilidad del autocrafteo. Son el tipo más general: indican «si un proveedor envía estos ingredientes a los inventarios adyacentes, el sistema ME recibirá estos resultados en algún momento». Permiten automatizar casi cualquier máquina de otros mods, hornos y similares. Como no importa lo que ocurra entre la entrega de ingredientes y la recepción del resultado, puedes hacer auténticas locuras: enviar los ingredientes a toda una cadena industrial que los clasifique, incorpore materiales de granjas de producción infinita y hasta imprima el guion completo de Bee Movie. Al sistema ME solo le importa recibir el resultado indicado. Ni siquiera exige relación entre los ingredientes y el resultado: un patrón de «1 tablón de cerezo = 1 estrella del Nether» funcionaría si tu granja de withers mata un wither al recibir un tablón de cerezo.

Puedes usar varios <ItemLink id="pattern_provider" /> con patrones idénticos para trabajar en paralelo. También puedes codificar «8 de roca = 8 de piedra» en vez de «1 de roca = 1 de piedra»: el proveedor enviará 8 de roca al sistema de fundición en cada operación, en lugar de uno por vez.

## La forma más general de un «patrón»

Existe una forma de «patrón» aún más general que la de procesamiento. Puedes configurar un <ItemLink id="level_emitter" /> con una tarjeta de crafteo para emitir redstone y así craftear algo. Este «patrón» no define ingredientes ni los necesita: solo indica «si este emisor produce redstone, el sistema ME recibirá este objeto en algún momento». Suele usarse para activar y desactivar granjas infinitas que no requieren ingredientes, o sistemas con recetas recursivas que el autocrafteo normal no puede interpretar. Por ejemplo, «1 de roca = 2 de roca» con una máquina que duplica roca.

# CPU de crafteo

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Las CPU de crafteo administran las solicitudes o tareas de crafteo. Guardan los ingredientes intermedios durante las tareas de varios pasos y determinan su tamaño y, hasta cierto punto, su velocidad. Son estructuras multibloque con forma de prisma rectangular y necesitan al menos 1 almacenamiento de crafteo.

Las CPU de crafteo se construyen con:

* **Obligatorio:** [almacenamientos de crafteo](../items-blocks-machines/crafting_cpu_multiblock.md), disponibles en los tamaños habituales: 1k, 4k, 16k, 64k y 256k. Guardan los ingredientes y productos intermedios del crafteo. Las tareas con más ingredientes requieren bloques de mayor capacidad o más bloques.
* **Opcional:** <ItemLink id="crafting_accelerator" />, que permiten enviar más lotes desde los proveedores. Así, un proveedor rodeado por 6 ensambladores moleculares puede abastecer y utilizar los 6 a la vez, en lugar de solo uno.
* **Opcional:** <ItemLink id="crafting_monitor" />, que muestran la tarea actual de la CPU. Puedes cambiar su color con un <ItemLink id="color_applicator" />.
* **Opcional:** <ItemLink id="crafting_unit" />, que rellenan los espacios para completar el prisma rectangular de la CPU.

Cada CPU de crafteo atiende 1 solicitud o tarea. Si quieres pedir a la vez un procesador de cálculo y 256 de piedra lisa, necesitas 2 CPU multibloque.

Puedes configurarlas para atender solicitudes de jugadores, de sistemas automáticos —buses de exportación e interfaces— o de ambos.

# Proveedores de patrones ME

<Row>
<BlockImage id="pattern_provider" scale="4" />

<BlockImage id="pattern_provider" p:push_direction="up" scale="4" />

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

Los <ItemLink id="pattern_provider" /> son la principal conexión entre el autocrafteo y el mundo. Envían los ingredientes de sus [patrones](../items-blocks-machines/patterns.md) a inventarios adyacentes y aceptan objetos para introducirlos en la red. A menudo puedes ahorrar un canal enviando la salida de una máquina por tuberías a un proveedor cercano, normalmente el mismo que entregó los ingredientes, en vez de recogerla con un <ItemLink id="import_bus" />.

Como entregan los ingredientes directamente desde el [almacenamiento de crafteo](../items-blocks-machines/crafting_cpu_multiblock.md#crafting-storage) de una CPU, nunca los guardan en su inventario: no puedes extraerlos con una tubería. Primero debes hacer que el proveedor los envíe a otro inventario, como un barril, y extraerlos desde allí.

Además, el proveedor debe entregar TODOS los ingredientes a la vez: no puede enviar medios lotes. Puedes aprovechar este comportamiento.

Los proveedores tienen una interacción especial con las interfaces de [subredes](../ae2-mechanics/subnetworks.md): si la interfaz no está configurada, con sus ranuras de solicitud vacías, el proveedor la omite y envía los ingredientes directamente al [almacenamiento](../ae2-mechanics/import-export-storage.md) de esa subred. Así no llena la interfaz con lotes y, sobre todo, no envía el siguiente hasta que haya espacio en el almacenamiento.

Puedes usar varios proveedores de patrones con patrones idénticos para trabajar en paralelo.

Los proveedores intentan repartir los lotes por turnos, en modo round robin, entre todas sus caras, usando en paralelo las máquinas conectadas.

## Variantes

Hay 3 variantes de proveedor de patrones: normal, direccional y plano. La variante determina por qué caras envía ingredientes, recibe objetos y establece conexiones de red.

* El proveedor normal envía ingredientes y recibe objetos por todas sus caras. Como la mayoría de las máquinas de AE2, actúa como un cable y conecta la red por todos sus lados.

* Para crear un proveedor direccional, usa una <ItemLink id="certus_quartz_wrench" /> sobre uno normal y cambia su orientación. Solo envía ingredientes por la cara seleccionada, recibe objetos por todas las caras y no conecta la red por la cara seleccionada. Esto permite abastecer máquinas de AE2 sin unir las redes, por ejemplo, para crear una subred.

* El proveedor plano es un [componente de cable](../ae2-mechanics/cable-subparts.md): puedes colocar varios sobre el mismo cable para crear instalaciones compactas. Su cara se comporta como la seleccionada en un proveedor direccional: entrega ingredientes de los patrones y recibe objetos, pero no establece una conexión de red.

Puedes alternar entre proveedores normales y planos colocándolos en una cuadrícula de crafteo.

## Ajustes

Los proveedores de patrones tienen varios modos:

* **Modo de bloqueo:** impide enviar un nuevo lote si ya hay ingredientes en la máquina.
* **Bloquear el crafteo:** bloquea el proveedor según distintas condiciones de redstone o hasta que el resultado anterior entre en ese mismo proveedor.
* Puedes mostrar u ocultar el proveedor en las <ItemLink id="pattern_access_terminal" />.

## Prioridad

Para establecer la prioridad, pulsa la llave de la esquina superior derecha de la interfaz. Si hay varios [patrones](../items-blocks-machines/patterns.md) para el mismo objeto, se prefieren los proveedores de mayor prioridad, salvo que la red no tenga los ingredientes necesarios para ese patrón.

# Ensambladores moleculares

<BlockImage id="molecular_assembler" scale="4" />

El <ItemLink id="molecular_assembler" /> recibe objetos, realiza la operación definida por un <ItemLink id="pattern_provider" /> adyacente o por el <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" /> o <ItemLink id="stonecutting_pattern" /> introducido, y envía el resultado a los inventarios adyacentes.

Su uso principal es junto a un <ItemLink id="pattern_provider" />. En ese caso, el proveedor envía la información del patrón junto con los ingredientes a los ensambladores adyacentes. Estos expulsan los resultados automáticamente a inventarios adyacentes, incluidas las ranuras de devolución del proveedor. Por eso basta con un ensamblador junto a un proveedor para automatizar los patrones de crafteo.

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>