---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Canales
  icon: controller
---

# Canales

Las [redes ME](me-network-connections.md) de Applied Energistics 2 necesitan canales para los [dispositivos](../ae2-mechanics/devices.md) que usan su almacenamiento u otros servicios. Piensa en ellos como cables USB: una computadora tiene un número limitado de puertos y dispositivos conectados. La mayoría de las máquinas, dispositivos de bloque completo y cables normales solo transmiten 8 canales: imagínalos como un haz de 8 «hilos de canal». Los [cables densos](../items-blocks-machines/cables.md#dense-cable) admiten hasta 32. Los únicos otros dispositivos que transmiten 32 son el <ItemLink id="me_p2p_tunnel" /> y el [puente de red cuántico](../items-blocks-machines/quantum_bridge.md). Cada dispositivo que consume un canal retira un «hilo USB» del haz, que deja de estar disponible más adelante.

<GameScene zoom="7" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_demonstration_1.snbt" />

  <LineAnnotation color="#33ff33" from="1 .4 .7" to="2.4 .4 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .7" to="2.4 .6 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .6" to="2.6 .4 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.4 .6 .7" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .4 .7" to="2.4 .4 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .6 .6" to="2.6 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 .6" to="2.6 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.1 .6 1.5" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 1.5" to="2.9 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.6 .6 1.5" to="2.6 .9 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .1 1.5" to="2.4 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .4" to="3.5 .6 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="3.5 .6 .4" to="3.5 .9 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="3.5 .1 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .3" to="1.5 .6 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1.5 .6 .3" to="1.5 .9 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1.5 .1 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#ff3333" from="3.5 .5 .5" to="5.5 .5 .5" alwaysOnTop={true}>
Los 8 canales del cable ya están ocupados: la unidad ME no recibe ninguno.
  </LineAnnotation>

  <LineAnnotation color="#993333" from="1 .5 .5" to="1.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="1.5 .5 .5" to="1.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2 .5 .5" to="2.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2.5 .5 .5" to="2.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="3 .5 .5" to="3.25 .5 .5" alwaysOnTop={true}/>

  <DiamondAnnotation pos="3.6 0.5 0.5" color="#ff0000">
Los 8 canales del cable ya están ocupados: la unidad ME no recibe ninguno.
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

Los [cables inteligentes](../items-blocks-machines/cables.md) permiten ver fácilmente cuántos canales se usan y por dónde pasan en tu red.

Los canales consumen 1⁄128 AE/t por cada nodo que atraviesan. Por eso, añadir un <ItemLink id="controller" /> a una red de 8 dispositivos y más de 96 nodos puede reducir el consumo: cambia la manera de distribuir los canales.

**LOS CANALES NO TIENEN NADA QUE VER CON EL COLOR DEL CABLE.** El color solo impide que ciertos cables se conecten entre sí.

<a name="channel-routing"></a>

## Enrutamiento de canales

Con un <ItemLink id="controller" />, los canales siguen 3 pasos. Primero recorren el camino más corto por las máquinas adyacentes hasta el [cable normal](../items-blocks-machines/cables.md) más cercano, de vidrio, recubierto o inteligente. Después recorren ese cable por el camino más corto hasta el [cable denso](../items-blocks-machines/cables.md) más cercano, normal o inteligente. Por último, siguen el camino más corto por ese cable hasta el <ItemLink id="controller" />. Si el camino más corto está lleno, algunos [dispositivos](devices.md) se quedarán sin canal. Usa colores, anclajes y túneles para dirigir los canales por donde necesitas.

En este ejemplo, algunas unidades ME no reciben canales aunque los cables tienen capacidad suficiente: los canales eligen el camino más corto, saturan algunos cables y dejan otros vacíos.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 3.6" to="1.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.4 0.5 3.6" to="1.4 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 1.6" to="0.6 .5 1.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 1.6" to="0.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 3.4" to="1.4 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 3.4" to="1.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <BoxAnnotation color="#dddddd" min="1.2 0.2 3.2" max="1.8 0.8 3.8" alwaysOnTop={true} thickness="0.05">
Intentan pasar más de 8 canales por aquí, así que algunos no pueden continuar.
  </BoxAnnotation>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

Puedes solucionarlo delimitando mejor las rutas. Conviene que la red tenga forma de árbol o arbusto, con la menor cantidad posible de bucles y rutas ambiguas.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue_fix.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 5.6" to="1 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

## Redes ad hoc

Una red sin <ItemLink id="controller" /> es una red ad hoc y admite hasta 8 dispositivos que necesitan canal. Al superar ese límite, todos los dispositivos que usan canales se apagan. Debes retirar dispositivos o añadir un <ItemLink id="controller" />.

A diferencia de las redes con controlador, los [cables inteligentes](../items-blocks-machines/cables.md) de una red ad hoc muestran los canales usados en toda la red, no los que atraviesan ese cable concreto.

En una red ad hoc, cada dispositivo consume 1 canal del total de la red. Es muy distinto de la distribución por el camino más corto que realiza un <ItemLink id="controller" />.

## Diseño

Como se explicó en [enrutamiento de canales](channels.md#channel-routing), conviene diseñar la red como un árbol: cables densos que salen del controlador, cables normales que se ramifican desde ellos y grupos de 8 [dispositivos](../ae2-mechanics/devices.md) o menos conectados a cada cable normal.

Este es un ejemplo de lo que debes evitar:

Si seguimos el recorrido de los canales:

1. Al salir del controlador hacia la derecha, la unidad ME limita el paso a 8 canales porque actúa como un cable normal. Como aquí no hay un cable inteligente, no podemos ver cuántos se usan. Quedan 8 canales.
2. La unidad ME consume uno. Quedan 7.
3. Suben 2 canales hacia las terminales. Quedan 5.
4. Más a la derecha, la interfaz consume otro. Quedan 4.
5. Sube 1 canal hacia el proveedor de patrones. Quedan 3.
6. Siguiendo a la derecha, sube 1 canal hacia el bus de importación. Quedan 2.
7. El grupo de proveedores que abastece a los ensambladores solo recibe 2 canales: 2 de sus proveedores se quedan sin canal.

El error consiste en crear un cuello de botella sin prever cómo se repartirán los canales.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/bad_network_structure.snbt" />

<LineAnnotation color="#33ff33" from="6.5 .5 1.5" to="6 .5 1.5" alwaysOnTop={true} thickness="0.4">
  32 canales
</LineAnnotation>

<LineAnnotation color="#33ff33" from="6 .5 1.5" to="5.5 .5 1.5" alwaysOnTop={true} thickness="0.2">
  8 canales
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 1.5 1.5" alwaysOnTop={true} thickness="0.1">
  2 canales
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 1.5 1.5" to="5.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 2.5 1.5" to="5.5 2.5 1.1" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="4.5 .5 1.5" alwaysOnTop={true} thickness="0.158">
  5 canales
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 1.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="3.5 .5 1.5" alwaysOnTop={true} thickness="0.122">
  3 canales
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="3.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 2.5 1.5" to="3.7 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="1.5 .5 1.5" alwaysOnTop={true} thickness="0.1">
  2 canales
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="1.5 0.3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="0.5 0.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="0.5 0.5 1.5" to="0.5 0.5 0.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#ff3333" from="0.5 1.5 1.5" to="0.5 1.3 1.5" alwaysOnTop={true} thickness="0.071">
  sin canales
</LineAnnotation>

<LineAnnotation color="#ff3333" from="1.5 1.5 0.5" to="1.5 1.3 0.5" alwaysOnTop={true} thickness="0.071">
  sin canales
</LineAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

---

Este es un ejemplo de una buena estructura:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="6.9 0 4.9" max="9.1 4 7.1" thickness="0.05">
Observa que los proveedores de patrones forman grupos separados de 8.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 4 4" max="8 5 5" thickness="0.05">
Dos cables normales llenos de canales confluyen aquí: necesitas un cable denso.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 0 13" max="8 1 14" thickness="0.05">
Los colores distintos impiden que se conecten los cables adyacentes.
    </BoxAnnotation>


  <IsometricCamera yaw="315" pitch="30" />
</GameScene>

## Modos de canales

AE2 10.0.0 para Minecraft 1.18 incorporó opciones para cambiar el funcionamiento de los canales. La opción de la sección general `channels` controla ese comportamiento. Los operadores pueden cambiar el modo y su configuración desde el juego con `/ae2 channelmode <mode>`, o consultar el modo actual con `/ae2 channelmode`. Al cambiarlo, todas las redes existentes se reinician y aplican el nuevo modo de inmediato.

Esto recupera y mejora la opción de Minecraft 1.12 para quienes prefieren una experiencia más relajada sin eliminar por completo la mecánica.

Estos son los modos disponibles tanto en la configuración como mediante el comando.

| Ajuste | Descripción |
| --- | --- |
| `default` | Modo normal, con las capacidades de cables y redes ad hoc descritas en esta guía. |
| `x2` | Duplica las capacidades: 16 canales en cables normales, 64 en densos y 16 en redes ad hoc. |
| `x3` | Triplica las capacidades: 24 canales en cables normales, 96 en densos y 24 en redes ad hoc. |
| `x4` | Cuadruplica las capacidades: 32 canales en cables normales, 128 en densos y 32 en redes ad hoc. |
| `infinite` | Elimina todos los límites de canales. Los controladores siguen reduciendo *considerablemente* el consumo. Los cables inteligentes solo se muestran totalmente apagados, sin canales, o totalmente encendidos, con 1 canal o más. |