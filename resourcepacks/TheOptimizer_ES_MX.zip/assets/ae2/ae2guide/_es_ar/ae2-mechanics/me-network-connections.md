---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Conexiones de red
  icon: fluix_glass_cable
---

# Conexiones de red

## ¿Qué significa «red»?

Una «red» es un grupo de [dispositivos](../ae2-mechanics/devices.md) unidos por bloques que transmiten [canales](../ae2-mechanics/channels.md), como [cables](../items-blocks-machines/cables.md), máquinas de bloque completo y otros [dispositivos](../ae2-mechanics/devices.md): <ItemLink id="charger" />, <ItemLink id="interface" />, <ItemLink id="drive" />, etc. De hecho, técnicamente un solo cable ya es una red.

## Una aclaración sobre la posición de los dispositivos

Para los [dispositivos](../ae2-mechanics/devices.md) con funciones de red, como una <ItemLink id="interface" /> que inserta y extrae del [almacenamiento de red](../ae2-mechanics/import-export-storage.md), un <ItemLink id="level_emitter" /> que consulta su contenido o una <ItemLink id="drive" /> que ofrece almacenamiento, la posición física no importa.

Repitamos: **la posición física del dispositivo no importa**. Solo importa que esté conectado a la red y, por supuesto, a cuál.

## Conexiones de red

Una <ItemLink id="network_tool" /> permite comprobar fácilmente qué está conectado. Muestra todos los componentes de la red: si aparecen elementos que no deberían, o faltan otros que sí, hay un problema.

Por ejemplo, aquí hay 2 redes separadas.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
Red 1
  </BoxAnnotation>

<BoxAnnotation color="#915dcd" min="2 0 0" max="3 2 2">
Red 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Aquí también hay 2 redes separadas: la <ItemLink id="quartz_fiber" /> comparte [energía](../ae2-mechanics/energy.md) sin establecer una conexión de red.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
Red 1
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="1.3 0 0" max="3 2 2">
Red 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

En cambio, aquí solo hay 1 red. El [puente cuántico](../items-blocks-machines/quantum_bridge.md) actúa como un [cable denso](../items-blocks-machines/cables.md#dense-cable) inalámbrico, así que ambos extremos pertenecen a la misma red.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="7 3 3">
Todo forma 1 red
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Aquí también hay 1 red. El color de los [cables](../items-blocks-machines/cables.md) solo impide que los de distintos colores se conecten entre sí. Todos los colores se conectan a los cables Fluix, los «sin teñir».

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
Todo forma 1 red
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Conexiones menos evidentes

En este caso solo hay 1 red: el <ItemLink id="pattern_provider" /> actúa como un cable por ser un dispositivo de bloque completo, y el <ItemLink id="inscriber" /> también. La conexión de red atraviesa ambos.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
Todo forma 1 red
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Para evitarlo, algo útil en muchos sistemas de autocrafteo con [subredes](../ae2-mechanics/subnetworks.md), haz click derecho sobre el proveedor con una <ItemLink id="certus_quartz_wrench" />. Pasará a ser direccional y dejará de transmitir canales por una de sus caras.

<Row gap="40">
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="2 2 2">
Red 1
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="2 0 0" max="4 2 2">
Red 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_directional_connection.snbt" />

  <BoxAnnotation color="#ee3333" min="1 .3 .3" max="1.3 .7 .7">
Observa que el cable no se conecta.
  </BoxAnnotation>

  <IsometricCamera yaw="255" pitch="30" />
</GameScene>
</Row>

Otros [dispositivos](../ae2-mechanics/devices.md) que no conectan la red a través de su cara son la mayoría de los [componentes de cable](../ae2-mechanics/cable-subparts.md), como los <ItemLink id="import_bus" />, los <ItemLink id="storage_bus" /> y las <ItemLink id="cable_interface" />.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/subpart_no_connection.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>