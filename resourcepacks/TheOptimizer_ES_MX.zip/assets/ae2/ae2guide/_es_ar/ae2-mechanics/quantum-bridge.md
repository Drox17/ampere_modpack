---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Puente cuántico
  icon: quantum_ring
---

# Puente de red cuántico

Consulta [puente de red cuántico](../items-blocks-machines/quantum_bridge.md).