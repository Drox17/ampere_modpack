---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: E/S espacial
  icon: spatial_storage_cell_2
---

# E/S espacial

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/spatial_storage_1x1x1.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="2 2 2">
El volumen que se trasladará
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />

</GameScene>

La E/S espacial permite cortar y pegar volúmenes físicos del mundo. Puedes mover una <ItemLink id="flawless_budding_quartz" />, intercambiar el interior de una habitación para darle distintos usos o incluso trasladar el portal del End.

Funciona *intercambiando* el volumen delimitado con otro del mismo tamaño en la dimensión de almacenamiento espacial. Lo que está entre los pilones va a esa dimensión y su contenido regresa al espacio entre los pilones.

Si tienes un modo de viajar entre dimensiones, puedes usar estos espacios como máquinas compactas de tamaño personalizado o dimensiones de bolsillo. La E/S espacial *puede* servir para crear un teletransportador, pero hacerlo es complejo, algo inestable y queda fuera de esta guía.

# Estructura multibloque

La E/S espacial necesita una disposición específica de sus componentes para funcionar y delimitar el volumen que se intercambiará.

Todos los componentes deben estar en la misma [red](me-network-connections.md). Solo puede haber una instalación de E/S espacial por red, por lo que conviene usar una [subred](subnetworks.md).

## Puerto de E/S espacial

<BlockImage id="spatial_io_port" p:powered="true" scale="4" />

El <ItemLink id="spatial_io_port" /> controla la operación. Muestra las estadísticas de la estructura multibloque y aloja las [celdas espaciales](../items-blocks-machines/spatial_cells.md).

Muestra:
- La [energía](energy.md) almacenada y la capacidad máxima de la red.
- La energía necesaria para la operación. Puede ser enorme y se consume de golpe: asegúrate de tener suficientes [celdas de energía](../items-blocks-machines/energy_cells.md) para almacenarla.
- La eficiencia del conjunto de pilones.
- El tamaño del volumen delimitado.

Para realizar una operación, coloca una celda de almacenamiento espacial en la ranura de entrada y envía un pulso de redstone al puerto. Se *intercambiará* el volumen entre los pilones con el de la dimensión espacial. Si envías unos bloques a esa dimensión, *colocas otros bloques entre los pilones*, vuelves a poner la celda en la entrada y activas el puerto, desaparecerá el segundo conjunto y reaparecerá el primero.

**CUIDADO: cualquier entidad dentro del volumen, incluido tú, viajará con él. Si no tienes cómo salir, quedarás atrapado en una caja oscura y vacía dentro de la dimensión espacial.** ¡Úsalo para gastar bromas a tus amigos!

## Pilones

<BlockImage id="spatial_pylon" p:powered_on="true" scale="4" />

Los <ItemLink id="spatial_pylon" /> son el elemento principal de la instalación y delimitan el volumen afectado.

El volumen corresponde a la caja que rodea los extremos exteriores de los pilones, reducida 1 bloque hacia dentro por cada lado.

Reglas:
- Tamaño mínimo de 3x3x3, que delimita un volumen de 1x1x1.
- Todos los pilones deben estar en la capa exterior que rodea el volumen.
- Todos deben pertenecer a la misma red.
- Cada tramo de pilones debe medir al menos 2 bloques de largo.

Por ejemplo, para delimitar 3x3x3, la segunda regla exige que los pilones estén en una envoltura de 5x5x5 alrededor del volumen. Casi cualquier distribución sirve, siempre que los pilones queden dentro de esa capa de 1 bloque de grosor.

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/spatial_storage_3x3x3_pylon_demonstration.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
El volumen que se trasladará
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Esta distribución es más razonable:

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/better_spatial_storage_3x3x3.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
El volumen que se trasladará
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Eficiencia

La eficiencia depende de cuánto de esa envoltura ocupen los pilones. Usar muy pocos alrededor de un volumen grande resulta ineficiente y puede exigir *miles de millones* de AE.

## Dimensiones de las celdas

Tras usar una [celda espacial](../items-blocks-machines/spatial_cells.md), sus dimensiones XYZ, por ejemplo 3x4x2, quedan fijadas permanentemente y vinculadas a un volumen de la dimensión espacial. **NO PUEDES REINICIAR, REFORMATEAR NI CAMBIAR EL TAMAÑO DE UNA CELDA ESPACIAL USADA.** Craftea otra si necesitas dimensiones distintas.

Estas dimensiones no son necesariamente las del nombre: una celda de 16^3 admite cualquier volumen *hasta* 16x16x16.

El volumen tiene orientación y no se puede girar. Uno de 2x2x3 no equivale a uno de 3x2x2, aunque tengan la misma capacidad.

Si las dimensiones XYZ de la celda no coinciden con el volumen delimitado que muestra el puerto, la operación no se realizará.