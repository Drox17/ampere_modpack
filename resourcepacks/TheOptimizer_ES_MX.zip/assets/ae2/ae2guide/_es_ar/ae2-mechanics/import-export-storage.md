---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Importación, exportación y almacenamiento
---

# Importación, exportación y almacenamiento

**Tu sistema ME y el mundo**

Un concepto importante es el almacenamiento de red: donde se guarda su contenido. Suele estar en [celdas de almacenamiento](../items-blocks-machines/storage_cells.md) o en el inventario conectado a un <ItemLink id="storage_bus" />. La mayoría de los [dispositivos](../ae2-mechanics/devices.md) de AE2 interactúan con él.

Por ejemplo:

* Los <ItemLink id="import_bus" /> introducen contenido en el almacenamiento de la red.
* Los <ItemLink id="export_bus" /> extraen contenido del almacenamiento de la red.
* Las <ItemLink id="interface" /> hacen ambas cosas.
* Las [terminales](../items-blocks-machines/terminals.md) insertan y extraen cuando depositas o retiras objetos y al rellenar las ranuras de crafteo.
* Los <ItemLink id="storage_bus" /> insertan y extraen del inventario conectado para usarlo como almacenamiento de red. En realidad, los otros dispositivos insertan y extraen *a través de ellos*.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_export_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="8 1 1" max="9 1.3 2">
Los buses de importación introducen en la red el contenido de los inventarios a los que apuntan.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="8 2 1" max="9 3 1.3">
Depositar un objeto de tu inventario en una terminal cuenta como una importación a la red.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="7 0 1" max="8 1 2">
Las interfaces importan desde sus ranuras internas si no tienen una reserva configurada o contienen más de lo establecido. Puedes introducir objetos en ellas para enviarlos a la red.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="6 0 1" max="7 1 2">
Los proveedores de patrones importan desde sus ranuras internas de devolución: puedes introducir objetos en ellas para enviarlos a la red.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 1" max="5 2 2">
Las unidades ME ofrecen las celdas que contienen como almacenamiento de red.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
Los buses de almacenamiento usan como almacenamiento de red el inventario al que apuntan.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 1" max="2 1.3 2">
Los buses de exportación envían contenido del almacenamiento de red al inventario al que apuntan.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="2 3 1.3">
Retirar un objeto de una terminal cuenta como una exportación de la red.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 1" max="1 2 2">
Las interfaces exportan hacia sus ranuras internas cuando tienen una reserva configurada: puedes extraer de ellas para retirar objetos de la red.
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Ten presentes las acciones de insertar y extraer del almacenamiento de red al diseñar instalaciones de automatización y logística.

<a name="storage-priority"></a>

## Prioridad de almacenamiento

Pulsa la llave de la esquina superior derecha de algunas interfaces para ajustar la prioridad. Los objetos que entran buscan primero el almacenamiento de mayor prioridad. Si varios tienen la misma, se prefiere el que ya contiene ese objeto. Las celdas con una lista de objetos permitidos cuentan como si ya los contuvieran. Al extraer se empieza por la prioridad más baja. Así, insertar y retirar contenido tiende a llenar los almacenamientos de mayor prioridad y vaciar los de menor prioridad.
