---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Dispositivos
  icon: interface
---

# Dispositivos

Un «dispositivo» es un componente de AE2 que realiza alguna función de la propia red. Casi todos necesitan un canal; la principal excepción son los [emisores de nivel](../items-blocks-machines/level_emitter.md).

Algunos ejemplos:

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
