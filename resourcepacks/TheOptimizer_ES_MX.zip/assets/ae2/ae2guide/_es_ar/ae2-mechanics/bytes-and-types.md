---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Bytes y tipos
  icon: creative_item_cell
---

# Bytes y tipos

<Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

Las [celdas de almacenamiento](../items-blocks-machines/storage_cells.md) tienen dos límites: *bytes* y *tipos*. Como en una computadora, los bytes miden la cantidad total de contenido que cabe en una celda. Los tipos miden cuántas clases distintas de objetos contiene. Cada objeto único es un tipo: 4,096 de roca ocupan 1 tipo, pero 16 espadas con encantamientos distintos ocupan 16 tipos.

Cada celda guarda una cantidad fija de datos. Cada tipo consume inicialmente cierta cantidad de bytes, según el tamaño de la celda. Además, cada objeto ocupa un bit: ocho objetos equivalen a un byte, y un stack de 64 ocupa 8 bytes, sin importar cómo se apile fuera de la red ME. Por ejemplo, 64 monturas idénticas no ocupan más que 64 de piedra.

Recuerda: cada objeto ocupa 1 bit, así que 8 objetos equivalen a 1 byte. En las celdas de fluidos, cada byte permite guardar 8 cubos.

Muchos se quejan del límite de tipos de las celdas, pero es una ***restricción necesaria***. Los datos se guardan en una etiqueta NBT del propio objeto, lo que hace que las celdas sean bastante estables. Sin embargo, acumular demasiados datos puede hacer que se envíe demasiada información al jugador y provocar algo parecido al «book banning» de Minecraft vanilla. Además, demasiados tipos aumentan el trabajo de clasificación y manejo de objetos. En la práctica, el límite no es tan restrictivo: una <ItemLink id="drive" /> llena de celdas admite 630 tipos, suficientes si no guardas cantidades enormes de objetos únicos que no se apilan.

El límite de tipos busca «disuadirte firmemente» de volcar directamente en el sistema ME los cientos de herramientas y piezas de armadura con daños aleatorios de una granja de mobs. Cada pieza con daño y encantamientos distintos requiere una entrada propia y aumenta los datos almacenados. Conviene filtrarlas antes de que lleguen al sistema.

Ir directamente a las celdas de mayor capacidad no suele ser lo mejor: cuestan más recursos, pero no admiten más tipos. Por eso todos los tamaños siguen siendo útiles incluso en etapas avanzadas, cada uno con sus ventajas y desventajas.

Esta tabla compara los tamaños de las celdas, su capacidad y un costo aproximado.

## Contenido de la celda frente a su costo

| Celda | Bytes | Tipos | Bytes por tipo | Certus | Redstone | Oro | Piedra luminosa |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| <ItemLink id="item_storage_cell_1k" /> | 1,024 | 63 | 8 | 4 | 5 | 1 | 0 |
| <ItemLink id="item_storage_cell_4k" /> | 4,096 | 63 | 32 | 14.25 | 20 | 3 | 0 |
| <ItemLink id="item_storage_cell_16k" /> | 16,384 | 63 | 128 | 45 | 61 | 9 | 4 |
| <ItemLink id="item_storage_cell_64k" /> | 65,536 | 63 | 512 | 137.25 | 184 | 27 | 16 |
| <ItemLink id="item_storage_cell_256k" /> | 262,144 | 63 | 2048 | 414 | 553 | 81 | 48 |

## Capacidad de almacenamiento según el número de tipos

El costo inicial por tipo hace que una celda con 1 tipo pueda guardar aproximadamente el doble que una con sus 63 tipos ocupados.

| Celda | Capacidad total con 1 tipo | Capacidad total con 63 tipos |
| --- | ---: | ---: |
| <ItemLink id="item_storage_cell_1k" /> | 8,128 | 4,160 |
| <ItemLink id="item_storage_cell_4k" /> | 32,512 | 16,640 |
| <ItemLink id="item_storage_cell_16k" /> | 130,048 | 66,560 |
| <ItemLink id="item_storage_cell_64k" /> | 520,192 | 266,240 |
| <ItemLink id="item_storage_cell_256k" /> | 2,080,768 | 1,064,960 |

![Celda con 1 tipo](../assets/diagrams/1_type_cell.png)

![Celda con 63 tipos](../assets/diagrams/63_type_cell.png)