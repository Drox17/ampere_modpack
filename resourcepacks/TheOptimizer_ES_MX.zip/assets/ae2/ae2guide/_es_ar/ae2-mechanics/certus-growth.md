---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Crecimiento del cuarzo Certus
  icon: quartz_cluster
---

# Crecimiento del cuarzo Certus

## Básicamente, copiado de la página de primeros pasos

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Los brotes de cuarzo Certus crecen en las [drusas de cuarzo Certus](../items-blocks-machines/budding_certus.md), de forma parecida a la amatista. Si rompes un brote antes de que termine de crecer, soltará un <ItemLink id="certus_quartz_dust" />, sin que Fortuna cambie la cantidad. Un cúmulo maduro suelta cuatro <ItemLink id="certus_quartz_crystal" />, y Fortuna aumenta esa cantidad.

Hay 4 estados de las drusas de cuarzo Certus: perfecta, imperfecta, astillada y dañada.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Cada vez que un brote avanza una etapa, la drusa puede deteriorarse un nivel hasta convertirse en un bloque de cuarzo Certus normal. Puedes repararla, o crear una nueva, lanzando al agua la drusa o un bloque de cuarzo Certus junto con uno o más <ItemLink id="charged_certus_quartz_crystal" />.

<RecipeFor id="damaged_budding_quartz" />

Las drusas perfectas no se deterioran y producen cuarzo Certus indefinidamente. Sin embargo, no se pueden craftear ni mover con un pico, ni siquiera con Toque de seda. Aunque *sí* puedes moverlas mediante el [almacenamiento espacial](../ae2-mechanics/spatial-io.md).

Los brotes de cuarzo Certus crecen muy despacio por sí solos. Por suerte, un <ItemLink id="growth_accelerator" /> junto a la drusa acelera enormemente el proceso. Tu primera prioridad debería ser construir unos cuantos.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_certus_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Si no tienes suficiente cuarzo para crear también un <ItemLink id="energy_acceptor" /> o una <ItemLink id="vibration_chamber" />, puedes colocar una <ItemLink id="crank" /> en el extremo del acelerador.

[Aquí se explica](../example-setups/simple-certus-farm.md) cómo cosechar cuarzo Certus automáticamente.