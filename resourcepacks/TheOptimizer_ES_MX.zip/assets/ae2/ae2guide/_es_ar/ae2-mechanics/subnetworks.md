---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Subredes
---

# Subredes

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/subnet_demonstration.snbt" />

<DiamondAnnotation pos="6.5 2.5 0.5" color="#00ff00">
Subred como tubería de objetos
    </DiamondAnnotation>

<DiamondAnnotation pos="5.5 2.5 0.5" color="#00ff00">
Subred como tubería de fluidos
    </DiamondAnnotation>

<DiamondAnnotation pos="4.5 2.5 0.5" color="#00ff00">
Plano de aniquilación filtrado
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 2.5 0.5" color="#00ff00">
Subred de plano de formación
    </DiamondAnnotation>

<DiamondAnnotation pos="2.5 2.5 0.5" color="#00ff00">
Subred que combina una interfaz y un bus de almacenamiento para ofrecer almacenamiento local accesible desde la red principal.
    </DiamondAnnotation>

<DiamondAnnotation pos="1.5 1.5 0.5" color="#00ff00">
Otra subred como tubería de objetos para devolver los objetos cargados al proveedor de patrones.
    </DiamondAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

«Subred» es un término flexible: suele ser una red auxiliar de la principal o dedicada a una tarea pequeña. Normalmente es lo bastante pequeña para funcionar sin controlador. Sus 2 usos principales son:

* Limitar a qué almacenamiento accede cada [dispositivo](../ae2-mechanics/devices.md). No conviene que el bus de importación de una subred «tubería» acceda al almacenamiento principal: enviaría los objetos a tus celdas en vez de al inventario de destino.
* Ahorrar canales en la red principal. Por ejemplo, un proveedor puede abastecer una interfaz conectada a varios buses de almacenamiento sobre distintas máquinas, usando 1 canal en vez de un proveedor y su canal por máquina.

Los colores de los cables solo ayudan a separar subredes porque los cables de colores distintos no se conectan entre sí.

Algunos ejemplos:

* Un bus de importación y uno de almacenamiento para transferir objetos o fluidos entre contenedores, como una tubería.
* Un plano de aniquilación y un bus de almacenamiento: el bus es el único destino de lo que rompe el plano, lo que permite filtrarlo.
* Una interfaz y un plano de formación: lo que entra en la interfaz se envía al plano y se coloca o suelta en el mundo.
* Una granja automática de cuarzo Certus, regulada por un <ItemLink id="level_emitter" /> de la red principal.
* Un almacenamiento especializado accesible desde la red principal mediante la interacción especial entre bus de almacenamiento e interfaz, para guardar la producción de una granja sin saturar las celdas principales.
* Y muchas otras posibilidades.

La <ItemLink id="quartz_fiber" /> es muy útil para las subredes: comparte energía sin unir las redes, evitando colocar receptores y cables de energía por todas partes.
