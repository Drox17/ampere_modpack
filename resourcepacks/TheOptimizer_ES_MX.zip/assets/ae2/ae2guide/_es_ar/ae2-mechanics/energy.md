---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Energía
  icon: energy_cell
---

# Energía

Tu red necesita energía. Tiene una reserva común de la que se abastecen directamente los [dispositivos](../ae2-mechanics/devices.md) y que reciben energía de las <ItemLink id="vibration_chamber" />, los <ItemLink id="energy_acceptor" /> y los <ItemLink id="controller" />. Puedes consultar las estadísticas con click derecho sobre cualquier parte de la red usando una <ItemLink id="network_tool" />, o directamente sobre el controlador si lo hay. Esta reserva y distribución comunes eliminan los límites de transferencia: los dispositivos pueden consumir cantidades muy altas y los receptores admitir energía a una velocidad prácticamente ilimitada, según la capacidad de almacenamiento de la red.

## Recepción de energía

<Row>
  <BlockImage id="energy_acceptor" scale="4" />

  <GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
  </GameScene>

  <BlockImage id="controller" p:state="online" scale="4" />

  <BlockImage id="vibration_chamber" p:active="true" scale="4" />
</Row>

AE2 no usa internamente Forge Energy en Forge ni TechReborn Energy en Fabric: las convierte a AE, su propia unidad. La conversión es de un solo sentido. Los <ItemLink id="energy_acceptor" /> y los <ItemLink id="controller" /> realizan esa conversión, aunque conviene reservar las caras del controlador para más [canales](../ae2-mechanics/channels.md). Las <ItemLink id="vibration_chamber" /> también generan energía, pero AE2 está pensado para combinarse con otros mods tecnológicos que ofrecen mejores fuentes de energía.

Por eso, al distribuir la energía de tu base conviene considerar cada red de AE2 como una gran máquina multibloque.

Las equivalencias de Forge Energy y TechReborn Energy son:

* 2 FE = 1 AE (Forge)
* 1 E = 2 AE (Fabric)

## Almacenamiento de energía

<Row>
  <BlockImage id="energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="4" />
</Row>

Una red no puede recibir ni consumir en un tick más energía de la que puede almacenar. Si su capacidad es de 800 AE, sus [dispositivos](../ae2-mechanics/devices.md) solo podrán consumir hasta 800 AE, con la reserva llena, y un receptor solo podrá introducir hasta 800 AE, con la reserva vacía.

Esto explica un fallo habitual: construyes una red pequeña con receptor, unidad ME, terminal y algunos dispositivos e intentas introducir de golpe un inventario lleno de roca. Insertarlo todo en un tick exige más energía de la que almacena la red: solo entra una parte, la reserva se agota y la red se reinicia.

**Se soluciona añadiendo celdas de energía.**

La red incluye una reserva de 25 AE por cable, máquina o componente.

Cada <ItemLink id="controller" /> almacena una pequeña reserva interna de 8,000 AE.

La <ItemLink id="energy_cell" /> guarda 200k AE. Una suele bastar para absorber sin problemas los picos de consumo del uso normal.

La <ItemLink id="dense_energy_cell" /> guarda 1.6M AE: sirve para alimentar una red desde una reserva o cubrir el enorme consumo instantáneo de grandes instalaciones de [almacenamiento espacial](spatial-io.md).

La <ItemLink id="creative_energy_cell" /> es un objeto del modo creativo para pruebas. Proporciona ¡ENERGÍAAA ILIMITADAAA!, o algo así.
