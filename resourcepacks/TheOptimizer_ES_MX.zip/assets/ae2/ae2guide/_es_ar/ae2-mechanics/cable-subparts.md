---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Componentes de los cables
icon: fluix_glass_cable
---

# Componentes de los cables

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/subparts_demonstration.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

En AE2, ciertos [dispositivos](devices.md) y componentes pueden compartir un bloque con un cable, lo que permite crear instalaciones compactas. Con Shift + click derecho y una <ItemLink id="certus_quartz_wrench" /> o una <ItemLink id="network_tool" /> puedes retirar un solo componente, o el cable, sin romper todo lo que hay en ese bloque.
