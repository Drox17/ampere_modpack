---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Meteoritos
  icon: sky_stone_block
---

# Meteoritos

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

Los meteoritos son el punto de partida de AE2. Contienen materiales esenciales: [drusas de cuarzo Certus](../items-blocks-machines/budding_certus.md) de varios estados y un <ItemLink id="mysterious_cube" /> en el centro.

En [primeros pasos](../getting-started.md) se explica qué hacer al encontrar uno.

## Cómo encontrar meteoritos

Los meteoritos son bastante comunes y dejan enormes cráteres, así que quizá ya hayas encontrado varios. Si no, una <ItemLink id="meteorite_compass" /> señala el cubo misterioso más cercano.

![Cráter de meteorito](../assets/assemblies/meteorite-crater.png)