---
navigation:
  parent: example-setups/example-setups-index.md
  title: Granja semiautomática de cuarzo Certus
  icon: certus_quartz_crystal
  position: 115
---

# Granja semiautomática de cuarzo Certus

La [granja sencilla](simple-certus-farm.md) necesita una <ItemLink id="flawless_budding_quartz" /> para funcionar sin intervención. Debes trasladarla mediante [E/S espacial](../ae2-mechanics/spatial-io.md) o construir la granja en el [meteorito](../ae2-mechanics/meteorites.md).

Pero AE2 puede colocar y romper bloques: quizá puedas hacer que la granja *sustituya las drusas por ti*. Tendrás que reponer periódicamente <ItemLink id="flawed_budding_quartz" /> en el barril de entrada y retirar <ItemLink id="quartz_block" /> del barril de drusas agotadas.

Para automatizarlo por completo, consulta [granja avanzada de cuarzo Certus](advanced-certus-farm.md).

Esta granja es algo más compleja que la [sencilla](simple-certus-farm.md) porque combina 3 instalaciones independientes en el mismo espacio.

**ES UNA CONSTRUCCIÓN COMPLEJA CON ELEMENTOS OCULTOS DETRÁS DE OTROS. GIRA LA VISTA PARA VERLA DESDE TODOS LOS ÁNGULOS.**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/semiauto_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
(1) Plano de aniquilación n.º 1: no tiene interfaz de configuración, pero admite Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1" max="2.3 3 2">
(2) Bus de almacenamiento n.º 1: filtrado para cristal de cuarzo Certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
Subred extractora de cúmulos
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
(3) Plano de aniquilación n.º 2: no tiene interfaz de configuración y lleva Toque de seda.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1" max="2.3 2 2">
(4) Bus de almacenamiento n.º 2: filtrado para bloque de cuarzo Certus.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
Subred extractora de bloques de cuarzo Certus
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
(5) Plano de formación: configuración predeterminada.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0 1" max="2.3 1 2">
(6) Bus de importación: configuración predeterminada.
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
Subred colocadora de drusas
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="0.7 2 1" max="1 3 2">
(7) Bus de almacenamiento n.º 3: filtrado para cristal de cuarzo Certus y con prioridad superior a la del almacenamiento principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

    <DiamondAnnotation pos="1.5 0.5 1.5" color="#00ff00">
Introduce manualmente drusas de cuarzo Certus imperfectas.
        <BlockImage id="flawed_budding_quartz" scale="2" />
    </DiamondAnnotation>

    <DiamondAnnotation pos="1.5 1.5 1.5" color="#00ff00">
Retira manualmente los bloques de cuarzo Certus.
        <BlockImage id="quartz_block" scale="2" />
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## Configuraciones

### Extractor de cúmulos:

* El primer <ItemLink id="annihilation_plane" /> (1) no tiene interfaz de configuración, pero admite Fortuna.
* El primer <ItemLink id="storage_bus" /> (2) filtra <ItemLink id="certus_quartz_crystal" />.

### Extractor de bloques de cuarzo Certus:

* El segundo <ItemLink id="annihilation_plane" /> (3) no tiene interfaz de configuración y debe llevar Toque de seda.
* El segundo <ItemLink id="storage_bus" /> (4) filtra <ItemLink id="quartz_block" />.

### Colocador de drusas:

* El <ItemLink id="formation_plane" /> (5) tiene la configuración predeterminada.
* El <ItemLink id="import_bus" /> (6) tiene la configuración predeterminada.

### En la red principal:

* El tercer <ItemLink id="storage_bus" /> (7) filtra <ItemLink id="certus_quartz_crystal" /> y tiene [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) superior a la del almacenamiento principal.

## Funcionamiento

### Extractor de cúmulos:

La subred extractora de cúmulos funciona casi igual que la de la [granja sencilla de cuarzo Certus](simple-certus-farm.md).

1. El <ItemLink id="annihilation_plane" /> intenta romper lo que tiene delante, pero solo puede romper <ItemLink id="quartz_cluster" />: su único almacenamiento es el <ItemLink id="storage_bus" />, filtrado para <ItemLink id="certus_quartz_crystal" />.
2. El <ItemLink id="storage_bus" /> guarda los cristales en el barril.

### Extractor de bloques de cuarzo Certus

La subred extractora de bloques rompe la drusa agotada cuando se convierte en un <ItemLink id="quartz_block" /> normal. Funciona de forma similar a la extractora de cúmulos.

1. El <ItemLink id="annihilation_plane" /> intenta romper lo que tiene delante, pero solo puede romper <ItemLink id="quartz_block" />: el único almacenamiento es el <ItemLink id="storage_bus" />, filtrado para <ItemLink id="quartz_block" />. Necesita Toque de seda para no deteriorar las drusas y evitar romperlas prematuramente.
2. El <ItemLink id="storage_bus" /> guarda el bloque en el barril de drusas agotadas. Deberás lanzarlo manualmente al agua con <ItemLink id="charged_certus_quartz_crystal" /> para renovarlo.

### Colocador de drusas

La subred colocadora pone una nueva <ItemLink id="flawed_budding_quartz" /> cuando la extractora rompe la anterior, ya agotada.

1. El <ItemLink id="import_bus" /> importa una drusa del barril de entrada.
2. El único almacenamiento es el <ItemLink id="formation_plane" />, que la coloca.

### En la red principal

* El <ItemLink id="storage_bus" /> permite a la red principal y al [cargador automático](charger-automation.md) acceder a los cristales del barril. Tiene [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) alta para que los cristales regresen allí en vez de al almacenamiento principal.