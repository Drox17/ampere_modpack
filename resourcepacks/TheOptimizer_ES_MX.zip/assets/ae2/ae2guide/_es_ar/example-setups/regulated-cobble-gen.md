---
navigation:
  parent: example-setups/example-setups-index.md
  title: Generador de roca autorregulado
  icon: minecraft:cobblestone
---

# Generador de roca autorregulado

Automatizar un generador de roca es sencillo: coloca un <ItemLink id="annihilation_plane" /> frente a un generador manual de Minecraft vanilla. Pero acabará llenando toda la red de roca, así que conviene regularlo.

Los planos de aniquilación actúan como <ItemLink id="import_bus" />. No basta con poner un <ItemLink id="level_emitter" /> frente a un <ItemLink id="export_bus" /> con una <ItemLink id="redstone_card" />: no se puede pasar directamente de importación a exportación sin almacenamiento intermedio. Hace falta otra estrategia.

Los <ItemLink id="toggle_bus" /> conectan y desconectan partes de la red mediante redstone, pero provocan un reinicio al cambiar. La solución es poner el bus en una [subred](../ae2-mechanics/subnetworks.md) para que solo se reinicie esta.

Una [subred](../ae2-mechanics/subnetworks.md) independiente con <ItemLink id="annihilation_plane" /> y <ItemLink id="storage_bus" /> puede introducir la roca en una <ItemLink id="interface" /> de la red principal. El bus conmutable conecta y desconecta la subred de una <ItemLink id="quartz_fiber" />, cortando la energía de los planos.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/regulated_cobble_gen.snbt" />

<BoxAnnotation color="#dddddd" min="3 2 2" max="7 2.3 3">
(1) Planos de aniquilación: no tienen interfaz de configuración, pero admiten Eficiencia e Irrompibilidad para reducir el consumo.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 2" max="2.3 3 3">
(2) Bus de almacenamiento: configuración predeterminada.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 2.3 2" max="2.7 2.7 2.3">
(3) Bus conmutable: es esencial que esté en la subred, no en la red principal.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 2.3" max="2.7 3.3 2.7">
(4) Emisor de nivel: configurado con roca y la cantidad deseada, en «Emitir por debajo del límite».
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 3" max="2 3 2">
(5) Interfaz: configuración predeterminada.
  </BoxAnnotation>

<DiamondAnnotation pos="0 2.5 1.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

<DiamondAnnotation pos="5 1.5 3.5" color="#00ff00">
Las escaleras anegadas impiden que el agua fluya y convierta la lava en obsidiana.
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* Los <ItemLink id="annihilation_plane" /> (1) no tienen interfaz de configuración, pero admiten Eficiencia e Irrompibilidad para reducir el consumo.
* El <ItemLink id="storage_bus" /> (2) tiene la configuración predeterminada.
* El <ItemLink id="toggle_bus" /> (3) debe estar del lado de la subred respecto a la fibra de cuarzo. Si queda en la principal, la reiniciará cada vez que cambie.
* El <ItemLink id="level_emitter" /> (4) tiene el objeto y la cantidad deseados, en «Emitir por debajo del límite».
* La <ItemLink id="interface" /> (5) tiene la configuración predeterminada.

## Funcionamiento

1. El generador produce roca.
2. Los <ItemLink id="annihilation_plane" /> la rompen.
3. El <ItemLink id="storage_bus" /> la guarda en la <ItemLink id="interface" />, que la introduce en la red principal.
4. Cuando la reserva supera la cantidad establecida, el <ItemLink id="level_emitter" /> deja de emitir y apaga el <ItemLink id="toggle_bus" />.
5. La subred pierde la energía y sus planos dejan de funcionar.
