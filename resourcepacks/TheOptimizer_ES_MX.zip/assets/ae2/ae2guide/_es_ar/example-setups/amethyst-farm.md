---
navigation:
  parent: example-setups/example-setups-index.md
  title: Granja de amatista
  icon: minecraft:amethyst_shard
---

# Cultivo de amatista

Aunque el <ItemLink id="growth_accelerator" /> funciona con amatista, el método habitual de filtrar los [brotes de cuarzo Certus](../items-blocks-machines/budding_certus.md) con un <ItemLink id="annihilation_plane" /> no sirve aquí. Los brotes inmaduros de Certus sueltan <ItemLink id="certus_quartz_dust" />; los de amatista no sueltan nada. El plano siempre los rompe porque una red siempre puede almacenar «nada».

La solución es encantar el plano con Toque de seda. Así los brotes inmaduros *sí* sueltan objetos, sus bloques en distintas etapas, y se pueden filtrar.

Después, un <ItemLink id="formation_plane" /> debe volver a colocar el <ItemLink id="minecraft:amethyst_cluster" /> para que otro <ItemLink id="annihilation_plane" /> sin Toque de seda lo rompa y produzca <ItemLink id="minecraft:amethyst_shard" />.

Por la orientación del cúmulo, debe haber una cara de bloque sólida justo enfrente del plano de formación.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/amethyst_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 1 1" max="3 2 2">
(1) Plano de aniquilación n.º 1: no tiene interfaz de configuración y lleva Toque de seda.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="2.3 2 2">
(2) Plano de formación: filtrado para cúmulo de amatista.
        <ItemImage id="minecraft:amethyst_cluster" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 0.7 1" max="2 1 2">
(3) Plano de aniquilación n.º 2: no tiene interfaz de configuración, pero admite Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="1.3 1 2">
(4) Bus de almacenamiento n.º 1: filtrado para fragmento de amatista.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 .7" max="1 1 1">
(5) Bus de almacenamiento n.º 2: filtrado para fragmento de amatista y con prioridad superior a la principal.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* El primer <ItemLink id="annihilation_plane" /> (1) debe llevar Toque de seda y no tiene interfaz de configuración.
* El <ItemLink id="formation_plane" /> (2) filtra <ItemLink id="minecraft:amethyst_cluster" />.
* El segundo <ItemLink id="annihilation_plane" /> (3) no tiene interfaz de configuración, pero admite Fortuna.
* El primer <ItemLink id="storage_bus" /> (4) filtra <ItemLink id="minecraft:amethyst_shard" />.
* El segundo <ItemLink id="storage_bus" /> (5) filtra <ItemLink id="minecraft:amethyst_shard" /> y tiene [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) superior a la principal.

## Funcionamiento

1. El primer <ItemLink id="annihilation_plane" /> intenta romper lo que tiene delante, pero solo puede romper <ItemLink id="minecraft:amethyst_cluster" />: su único almacenamiento es el <ItemLink id="formation_plane" />, filtrado para cúmulos. Esto requiere Toque de seda; sin él, también rompería los brotes inmaduros porque no sueltan nada.
2. El <ItemLink id="formation_plane" /> coloca el cúmulo en el bloque opuesto.
3. El segundo <ItemLink id="annihilation_plane" /> lo rompe y produce <ItemLink id="minecraft:amethyst_shard" />.
4. El primer <ItemLink id="storage_bus" /> guarda los fragmentos en el barril. En realidad no necesita filtro, pues el segundo plano solo debería encontrar cúmulos maduros.
5. El segundo <ItemLink id="storage_bus" /> permite a la red principal acceder a todos los fragmentos del barril. Su [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) alta hace que regresen preferentemente allí en vez de al almacenamiento principal.
