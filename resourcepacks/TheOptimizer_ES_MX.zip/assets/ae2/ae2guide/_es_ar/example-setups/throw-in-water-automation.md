---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatización de recetas al lanzar objetos al agua
  icon: fluix_crystal
---

# Automatización de recetas al lanzar objetos al agua

Como usa un <ItemLink id="pattern_provider" />, esta instalación se integra en el [autocrafteo](../ae2-mechanics/autocrafting.md).

Algunas recetas requieren lanzar objetos al agua; una instalación parecida puede lanzarlos a otros sitios. Se automatiza con un <ItemLink id="formation_plane" />, un <ItemLink id="annihilation_plane" /> y algunos componentes auxiliares. Básicamente son 2 [subredes tipo tubería](pipe-subnet.md) modificadas.

Está pensada para combinarse con un [cargador automático](charger-automation.md) que suministre los <ItemLink id="charged_certus_quartz_crystal" />.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
(1) Proveedor de patrones: configuración predeterminada, con los patrones de procesamiento correspondientes.

![Patrón de Fluix](../assets/diagrams/fluix_pattern_small.png) ![Patrón de drusa imperfecta](../assets/diagrams/flawed_budding_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 1" max="2 1 2">
(2) Interfaz: configuración predeterminada.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 .7 1" max="2 1 2">
(3) Plano de formación: configurado para soltar objetos.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 2 1" max="2 2.3 2">
(4) Plano de aniquilación: sin interfaz de configuración.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
(5) Bus de almacenamiento: filtra los resultados de los patrones.
        <Row><ItemImage id="fluix_crystal" scale="2" /><BlockImage id="flawless_budding_quartz" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="3.9 0.5 1.5" color="#00ff00">
Hacia la red principal y el cargador automático.
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
    </DiamondAnnotation>

  <IsometricCamera yaw="180" pitch="0" />
</GameScene>

## Configuraciones y patrones

* El <ItemLink id="pattern_provider" /> (1) tiene la configuración predeterminada y los <ItemLink id="processing_pattern" /> correspondientes.
    * Para <ItemLink id="fluix_crystal" /> sirve la receta normal de JEI/REI:

![Patrón de Fluix](../assets/diagrams/fluix_pattern.png)

    * Para <ItemLink id="flawed_budding_quartz" /> conviene usar directamente <ItemLink id="quartz_block" />. Así el ingrediente de una receta no es también el resultado de otra, lo que impediría filtrar correctamente al bus:

![Patrón de drusa imperfecta](../assets/diagrams/flawed_budding_pattern.png)

* La <ItemLink id="interface" /> (2) tiene la configuración predeterminada.
* El <ItemLink id="formation_plane" /> (3) suelta los materiales como objetos.
* El <ItemLink id="annihilation_plane" /> (4) no tiene interfaz de configuración.
* El <ItemLink id="storage_bus" /> (5) filtra los resultados de los patrones.

## Funcionamiento

1. El <ItemLink id="pattern_provider" /> envía los ingredientes a la <ItemLink id="interface" /> adyacente de la subred verde.
2. Como no tiene reservas configuradas, la interfaz intenta introducirlos en el [almacenamiento de red](../ae2-mechanics/import-export-storage.md).
3. Su único almacenamiento es el <ItemLink id="formation_plane" />, que los suelta al agua.
4. El <ItemLink id="annihilation_plane" /> de la subred naranja intenta recogerlos, pero el <ItemLink id="storage_bus" /> sobre el proveedor, su único almacenamiento, solo admite resultados de las recetas posibles.
5. Los objetos realizan su transformación en el mundo.
6. Ahora el plano sí puede recogerlos porque el bus permite almacenarlos.
7. El bus los introduce en el proveedor y los devuelve a la red.
