---
navigation:
  parent: example-setups/example-setups-index.md
  title: Granja avanzada de cuarzo Certus
  icon: certus_quartz_crystal
  position: 120
---

# Granja avanzada de cuarzo Certus

Esta es una [granja semiautomática de cuarzo Certus](semiauto-certus-farm.md) totalmente integrada en tu sistema ME.

En lugar de acumular drusas y renovarlas manualmente cada cierto tiempo, esta instalación combina la [automatización del cargador](charger-automation.md) con la [automatización de recetas al lanzar objetos al agua](throw-in-water-automation.md) para hacerlo sola.

**ES UNA CONSTRUCCIÓN COMPLEJA CON ELEMENTOS OCULTOS DETRÁS DE OTROS. GIRA LA VISTA PARA VERLA DESDE TODOS LOS ÁNGULOS.**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/advanced_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
(1) Plano de aniquilación n.º 1: no tiene interfaz de configuración, pero admite Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1.7" max="3 3 2">
(2) Bus de almacenamiento n.º 1: filtrado para cristal de cuarzo Certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
Subred extractora de cúmulos
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
(3) Plano de aniquilación n.º 2: no tiene interfaz de configuración y lleva Toque de seda.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1.7" max="3 2 2">
(4) Bus de almacenamiento n.º 2: filtrado para bloque de cuarzo Certus.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
Subred extractora de bloques de cuarzo Certus
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
(5) Plano de formación: configuración predeterminada.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0.7 2" max="3 1 3">
(6) Bus de importación: filtrado para drusa de cuarzo Certus imperfecta.
        <BlockImage id="flawed_budding_quartz" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
Subred colocadora de drusas
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="1.7 2 2" max="2 3 3">
(7) Bus de almacenamiento n.º 3: filtrado para cristal de cuarzo Certus y con prioridad superior a la del almacenamiento principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#aaaadd" min="2 1 2" max="3 2 3">
(8) Interfaz: mantiene 1 drusa de cuarzo Certus imperfecta y tiene una tarjeta de crafteo.
        <Row><BlockImage id="flawed_budding_quartz" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="1.5 0.5 0" color="#00ff00">
Hacia la red principal, el cargador automático y la automatización de recetas en agua.
        <Row>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        </Row>
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## Configuraciones

### Extractor de cúmulos:

* El primer <ItemLink id="annihilation_plane" /> (1) no tiene interfaz de configuración, pero admite Fortuna.
* El primer <ItemLink id="storage_bus" /> (2) filtra <ItemLink id="certus_quartz_crystal" />.

### Extractor de bloques de cuarzo Certus:

* El segundo <ItemLink id="annihilation_plane" /> (3) no tiene interfaz de configuración y debe llevar Toque de seda.
* El segundo <ItemLink id="storage_bus" /> (4) filtra <ItemLink id="quartz_block" />.

### Colocador de drusas:

* El <ItemLink id="formation_plane" /> (5) tiene la configuración predeterminada.
* El <ItemLink id="import_bus" /> (6) filtra <ItemLink id="flawed_budding_quartz" />.

### En la red principal:

* El tercer <ItemLink id="storage_bus" /> (7) filtra <ItemLink id="certus_quartz_crystal" /> y tiene [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) superior a la del almacenamiento principal.
* La <ItemLink id="interface" /> (8) mantiene 1 drusa de cuarzo Certus imperfecta y tiene una <ItemLink id="crafting_card" />.

## Funcionamiento

### Extractor de cúmulos:

La subred extractora de cúmulos funciona casi igual que la de la [granja sencilla de cuarzo Certus](simple-certus-farm.md).

1. El <ItemLink id="annihilation_plane" /> intenta romper lo que tiene delante, pero solo puede romper <ItemLink id="quartz_cluster" />: su único almacenamiento es el <ItemLink id="storage_bus" />, filtrado para <ItemLink id="certus_quartz_crystal" />.
2. El <ItemLink id="storage_bus" /> guarda los cristales en el barril.

### Extractor de bloques de cuarzo Certus

La subred extractora de bloques rompe la drusa agotada cuando se convierte en un <ItemLink id="quartz_block" /> normal. Funciona de forma similar a la extractora de cúmulos.

1. El <ItemLink id="annihilation_plane" /> intenta romper lo que tiene delante, pero solo puede romper <ItemLink id="quartz_block" />: el único almacenamiento es el <ItemLink id="storage_bus" />, filtrado para <ItemLink id="quartz_block" />. Necesita Toque de seda para que la drusa no se deteriore al romperla; así no la rompe antes de agotarse.
2. El <ItemLink id="storage_bus" /> guarda el bloque en la <ItemLink id="interface" /> para que la [automatización de recetas en agua](throw-in-water-automation.md) lo convierta en una nueva <ItemLink id="flawed_budding_quartz" />.

### Colocador de drusas

La subred colocadora pone una nueva <ItemLink id="flawed_budding_quartz" /> cuando la extractora rompe la anterior, ya agotada.

1. El <ItemLink id="import_bus" /> importa una drusa desde la <ItemLink id="interface" /> al [almacenamiento de red](../ae2-mechanics/import-export-storage.md).
2. El único almacenamiento de la subred es el <ItemLink id="formation_plane" />, que coloca la drusa.

### En la red principal

* El <ItemLink id="storage_bus" /> permite a la red principal y al [cargador automático](charger-automation.md) acceder a los cristales del barril. Tiene [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) alta para que regresen preferentemente allí en vez de al almacenamiento principal.
* La <ItemLink id="interface" /> ofrece una <ItemLink id="flawed_budding_quartz" /> a la subred colocadora y permite que la extractora devuelva los bloques agotados a la red principal. Su <ItemLink id="crafting_card" /> solicita nuevas drusas al [autocrafteo](../ae2-mechanics/autocrafting.md) de la red principal.