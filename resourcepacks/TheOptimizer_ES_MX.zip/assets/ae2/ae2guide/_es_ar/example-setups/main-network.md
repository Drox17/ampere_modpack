---
navigation:
  parent: example-setups/example-setups-index.md
  title: Ejemplo de «red principal»
  icon: controller
---

# Ejemplo de «red principal»

Otros ejemplos mencionan una «red principal». Quizá quieras ver cómo se combinan estos [dispositivos](../ae2-mechanics/devices.md) en un sistema funcional. Aquí tienes un ejemplo:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="3.9 0 1.9" max="9.1 5 7.1" thickness="0.05">
Este grupo de proveedores y ensambladores admite muchos patrones de crafteo, cortapiedras y herrería. La distribución en damero permite compartir ensambladores y trabajar en paralelo sin perder espacio. Los grupos de 8 evitan rutas de canales incorrectas.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="3.9 0 9.9" max="5.1 3 12.1" thickness="0.05">
Algunas máquinas con una subred tipo tubería para devolver sus resultados a los proveedores.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="-0.1 0 8.9" max="1.1 3 13.1" thickness="0.05">
Terminales y otros accesorios útiles. Probablemente te baste una terminal de crafteo, en vez de una terminal normal *y* otra de crafteo.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="-0.1 0 -0.1" max="2.1 3 8.1" thickness="0.05">
Un conjunto de CPU de crafteo: algunas con más almacenamiento y más unidades con poca capacidad. Para un sistema real conviene añadir más coprocesadores, pero la escena quedaría demasiado grande.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5.9 0 13.9" max="7.1 1 15.1" thickness="0.05">
El controlador debería estar en el centro de la base y ser algo mayor. Una forma alargada funciona bastante bien.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="11.9 0 7.9" max="13.1 4 13.1" thickness="0.05">
Distintas formas de almacenar con unidades ME o buses de almacenamiento. Observa los grupos de 8.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="10.9 0 0.9" max="13.1 2 7.1" thickness="0.05">
Distintas formas de almacenar con unidades ME o buses de almacenamiento. Observa los grupos de 8.
    </BoxAnnotation>

  <IsometricCamera yaw="315" pitch="30" />
</GameScene>
