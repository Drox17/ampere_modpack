---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatización del horno
  icon: minecraft:furnace
---

# Automatización del horno

Como usa un <ItemLink id="pattern_provider" />, esta instalación se integra en el [autocrafteo](../ae2-mechanics/autocrafting.md). Si solo quieres automatizar un horno independiente, usa tolvas, cofres y similares.

Automatizar un <ItemLink id="minecraft:furnace" /> es algo más complejo que un [cargador](../example-setups/charger-automation.md): requiere entradas por dos caras y extracción por una tercera. El objeto que se fundirá entra por arriba, el combustible por un lateral y el resultado sale por abajo.

Podrías poner un <ItemLink id="pattern_provider" /> arriba, un <ItemLink id="export_bus" /> en un lateral para reponer combustible y un <ItemLink id="import_bus" /> debajo para recoger el resultado. Pero eso consume 3 [canales](../ae2-mechanics/channels.md).

Así puedes hacerlo con solo 1 canal:

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
(1) Proveedor de patrones: variante direccional, orientada con una llave de cuarzo Certus, con los patrones de procesamiento correspondientes.

![Patrón de hierro](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
(2) Interfaz: configuración predeterminada.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
(3) Bus de almacenamiento n.º 1: filtrado para carbón.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
(4) Bus de almacenamiento n.º 2: excluye el carbón mediante una tarjeta inversora.
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* El <ItemLink id="pattern_provider" /> (1) tiene la configuración predeterminada y los <ItemLink id="processing_pattern" /> correspondientes. Se vuelve direccional al orientarlo con una <ItemLink id="certus_quartz_wrench" />.

![Patrón de hierro](../assets/diagrams/furnace_pattern.png)

* La <ItemLink id="interface" /> (2) tiene la configuración predeterminada.
* El primer <ItemLink id="storage_bus" /> (3) filtra carbón o el combustible elegido.
* El segundo <ItemLink id="storage_bus" /> (4) excluye ese combustible mediante una <ItemLink id="inverter_card" />.

## Funcionamiento

1. El <ItemLink id="pattern_provider" /> envía los ingredientes a la <ItemLink id="interface" />. En realidad, una optimización los envía directamente por los buses como si fueran extensiones de sus caras: no llegan a entrar en la interfaz.
2. Como la interfaz no tiene reservas configuradas, intenta introducirlos en el [almacenamiento de red](../ae2-mechanics/import-export-storage.md).
3. Sus únicos almacenamientos son los <ItemLink id="storage_bus" />: el que filtra carbón lo introduce por el lateral en la ranura de combustible; el que lo excluye introduce los objetos por arriba en la ranura de fundición.
4. El horno hace lo suyo.
5. La tolva extrae los resultados por abajo y los deposita en las ranuras de devolución del proveedor, enviándolos a la red principal.
