---
navigation:
  parent: example-setups/example-setups-index.md
  title: Reposición automática con un emisor de nivel
  icon: level_emitter
---

# Reposición automática con un emisor de nivel

Quizá te preguntes: «¿Cómo mantengo una reserva de un objeto y crafteo más cuando haga falta?».

Una solución combina un <ItemLink id="export_bus" />, un <ItemLink id="level_emitter" /> y una <ItemLink id="crafting_card" /> para solicitar objetos al [autocrafteo](../ae2-mechanics/autocrafting.md). Sirve para mantener una cantidad grande de un solo objeto.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/level_emitter_autostocking.snbt" />

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
(1) Bus de exportación: filtrado para el objeto deseado, con tarjeta de redstone y tarjeta de crafteo. Modo de redstone: «Activo con señal». Comportamiento de crafteo: «No usar objetos almacenados».
        <Row><ItemImage id="redstone_card" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0.7 1 0" max="1 2 1">
(2) Emisor de nivel: configurado con el objeto y la cantidad deseados, en «Emitir por debajo del límite».
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
(3) Interfaz: configuración predeterminada.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* El <ItemLink id="export_bus" /> (1) filtra el objeto deseado y lleva una <ItemLink id="redstone_card" /> y una <ItemLink id="crafting_card" />. Configura «Modo de redstone» en «Activo con señal» y «Comportamiento de crafteo» en «No usar objetos almacenados».
* El <ItemLink id="level_emitter" /> (2) tiene el objeto y la cantidad deseados, en «Emitir por debajo del límite».
* La <ItemLink id="interface" /> (3) tiene la configuración predeterminada.

## Funcionamiento

1. Si el [almacenamiento de red](../ae2-mechanics/import-export-storage.md) contiene menos objetos que lo indicado en el <ItemLink id="level_emitter" />, este emite redstone.
2. Al recibir la señal, y gracias a la <ItemLink id="crafting_card" /> y a no usar las existencias, el <ItemLink id="export_bus" /> pide más objetos al [autocrafteo](../ae2-mechanics/autocrafting.md) y luego los exporta.
3. La <ItemLink id="interface" /> recibe el objeto y, como no tiene reservas configuradas, lo introduce en el almacenamiento de red.