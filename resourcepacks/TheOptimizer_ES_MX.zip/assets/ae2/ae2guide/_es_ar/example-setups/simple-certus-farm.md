---
navigation:
  parent: example-setups/example-setups-index.md
  title: Granja sencilla de cuarzo Certus
  icon: certus_quartz_crystal
  position: 110
---

# Granja sencilla de cuarzo Certus

Como explica [crecimiento del cuarzo Certus](../ae2-mechanics/certus-growth.md), la cosecha automática de <ItemLink id="certus_quartz_crystal" /> usa <ItemLink id="annihilation_plane" /> y <ItemLink id="storage_bus" />. Los <ItemLink id="growth_accelerator" /> aceleran mucho los brotes; después, los planos rompen los <ItemLink id="quartz_cluster" /> maduros. El filtro aprovecha una coincidencia sospechosamente conveniente: los brotes inmaduros sueltan <ItemLink id="certus_quartz_dust" /> en lugar de no soltar nada.

Con una <ItemLink id="flawless_budding_quartz" />, funciona sin intervención. Las drusas imperfectas, astilladas y dañadas deben sustituirse manualmente, o automáticamente como explican la [granja semiautomática](semiauto-certus-farm.md) y la [avanzada](advanced-certus-farm.md).

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/simple_certus_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 1 1" max="4 2 2">
(1) Plano de aniquilación: no tiene interfaz de configuración, pero admite Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="3.3 2 2">
(2) Bus de almacenamiento n.º 1: filtrado para cristal de cuarzo Certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 .7" max="2 2 1">
(3) Bus de almacenamiento n.º 2: filtra cristales de cuarzo Certus y tiene prioridad superior a la principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* El primer <ItemLink id="annihilation_plane" /> (1) no tiene interfaz de configuración, pero admite Fortuna.
* El primer <ItemLink id="storage_bus" /> (2) filtra <ItemLink id="certus_quartz_crystal" />.
* El segundo <ItemLink id="storage_bus" /> (3) filtra <ItemLink id="certus_quartz_crystal" /> y tiene [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) superior a la principal.

## Funcionamiento

1. El <ItemLink id="annihilation_plane" /> solo puede romper <ItemLink id="quartz_cluster" /> porque su único almacenamiento es el <ItemLink id="storage_bus" />, filtrado para <ItemLink id="certus_quartz_crystal" />.
4. El primer <ItemLink id="storage_bus" /> guarda los cristales en el barril.
5. El segundo <ItemLink id="storage_bus" /> permite a la red principal acceder a ellos. Su [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) alta hace que regresen preferentemente al barril en vez de al almacenamiento principal.
