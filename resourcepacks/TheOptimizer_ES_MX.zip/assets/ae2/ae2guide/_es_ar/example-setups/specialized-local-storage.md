---
navigation:
  parent: example-setups/example-setups-index.md
  title: Almacenamiento local especializado
  icon: drive
---

# Almacenamiento local especializado

Una de las [interacciones especiales de la interfaz](../items-blocks-machines/interface.md#special-interactions) permite que una [subred](../ae2-mechanics/subnetworks.md) ofrezca su almacenamiento a la principal sin acceder al almacenamiento de esta, usando solo 1 [canal](../ae2-mechanics/channels.md).

Sirve para almacenar la producción junto a una granja sin que los excedentes llenen el almacenamiento principal.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/local_storage.snbt" />

<BoxAnnotation color="#dddddd" min="4 0 0" max="5 2 1">
(1) Método de importación de objetos: en este caso, una interfaz.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 0 0" max="4 1 1">
(2) Unidad ME: contiene celdas filtradas para los productos de la granja. Pueden llevar tarjetas de distribución equitativa y de destrucción de excedentes.
        <Row><ItemImage id="item_storage_cell_4k" scale="2" /> <ItemImage id="equal_distribution_card" scale="2" /> <ItemImage id="void_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 0" max="4 2 0.3">
(3) Terminal de crafteo: ve las celdas de la subred, pero no el almacenamiento principal.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
(4) Interfaz n.º 2: configuración predeterminada.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 0" max="2 1 1">
(5) Bus de almacenamiento: prioridad superior a la principal; puede filtrar los productos de la granja.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 0.3">
Terminal de crafteo: ve tanto el almacenamiento principal *como* el de la subred.
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* La primera <ItemLink id="interface" /> (1) recibe los productos de la granja y los introduce en la subred.
* La <ItemLink id="drive" /> (2) contiene [celdas](../items-blocks-machines/storage_cells.md) que conviene [particionar](../items-blocks-machines/cell_workbench.md) para los productos de la granja. Pueden llevar <ItemLink id="equal_distribution_card" /> y <ItemLink id="void_card" />.
* La segunda <ItemLink id="interface" /> (4) tiene la configuración predeterminada.
* El <ItemLink id="storage_bus" /> tiene [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) superior a la principal y puede filtrar los productos de la granja.

## Funcionamiento

* La <ItemLink id="interface" /> de la subred muestra al <ItemLink id="storage_bus" /> principal el contenido de la <ItemLink id="drive" />. El bus puede insertar y extraer directamente de sus celdas.
* La [prioridad](../ae2-mechanics/import-export-storage.md#storage-priority) alta hace que los objetos regresen preferentemente a la subred.
* Si sus celdas se llenan, el excedente no pasa a la red principal. Si la granja falla al atascarse, usa <ItemLink id="void_card" /> para destruir el sobrante.
* Si produce varios objetos, las <ItemLink id="equal_distribution_card" /> evitan que uno ocupe todas las celdas e impida almacenar los demás.