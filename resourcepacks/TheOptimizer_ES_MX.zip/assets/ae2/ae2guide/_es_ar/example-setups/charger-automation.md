---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatización del cargador
  icon: charger
---

# Automatización del cargador

Como usa un <ItemLink id="pattern_provider" />, esta instalación se integra en el [autocrafteo](../ae2-mechanics/autocrafting.md). Si solo quieres automatizar un <ItemLink id="charger" /> independiente, basta con tolvas, cofres y similares.

Automatizar un <ItemLink id="charger" /> es sencillo. Un <ItemLink id="pattern_provider" /> introduce el ingrediente y una [subred tipo tubería](pipe-subnet.md), u otra tubería de objetos, devuelve el resultado al proveedor.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/charger_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
(1) Proveedor de patrones: configuración predeterminada, con los patrones de procesamiento correspondientes. También alimenta el cargador.

![Patrón del cargador](../assets/diagrams/charger_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="1 1.3 1">
(2) Bus de importación: configuración predeterminada.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
(3) Bus de almacenamiento: configuración predeterminada.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* El <ItemLink id="pattern_provider" /> (1) tiene la configuración predeterminada y los <ItemLink id="processing_pattern" /> correspondientes. También suministra [energía](../ae2-mechanics/energy.md) al <ItemLink id="charger" /> porque actúa como un [cable](../items-blocks-machines/cables.md).
  
![Patrón del cargador](../assets/diagrams/charger_pattern.png)

* El <ItemLink id="import_bus" /> (2) tiene la configuración predeterminada.
* El <ItemLink id="storage_bus" /> (3) tiene la configuración predeterminada.

## Funcionamiento

1. El <ItemLink id="pattern_provider" /> introduce los ingredientes en el <ItemLink id="charger" />.
2. El cargador hace lo suyo.
3. El <ItemLink id="import_bus" /> de la subred verde extrae el resultado e intenta guardarlo en el [almacenamiento de red](../ae2-mechanics/import-export-storage.md).
4. El único almacenamiento de esa subred es el <ItemLink id="storage_bus" />, que lo introduce en el proveedor y lo devuelve a la red principal.
