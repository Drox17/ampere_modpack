---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatización de procesadores
  icon: inscriber
---

# Producción automática de procesadores

Esta es una de las muchas formas de automatizar [procesadores](../items-blocks-machines/processors.md).

La distribución general funciona con cualquier tubería o conducto de logística de objetos, se llame como se llame en su mod, siempre que permita filtrar.

![Diagrama del proceso](../assets/diagrams/processor_flow_diagram.png)

Aquí se explica cómo hacerlo solo con AE2, mediante [subredes tipo tubería](pipe-subnet.md).

Como usa un <ItemLink id="pattern_provider" />, se integra en el [autocrafteo](../ae2-mechanics/autocrafting.md). Para producir procesadores de forma independiente, sustituye el proveedor por otro barril e introduce los ingredientes directamente en el barril superior.

También funciona con versiones anteriores de AE2: aunque los <ItemLink id="inscriber" /> limiten el acceso según la cara, estas subredes siguen insertando y extrayendo por las caras correctas.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/processor_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="5 1 0" max="6 2 1" thickness=".05">
(1) Proveedor de patrones: configuración predeterminada, con los patrones de procesamiento correspondientes.

        <Row>
![Patrón de procesador lógico](../assets/diagrams/logic_pattern_small.png)
![Patrón de procesador de cálculo](../assets/diagrams/calculation_pattern_small.png)
![Patrón de procesador de ingeniería](../assets/diagrams/engineering_pattern_small.png)
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.7 2 0" max="5 3 1" thickness=".05">
(2) Bus de almacenamiento n.º 1: configuración predeterminada.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="4.3 2 1" thickness=".05">
(3) Bus de exportación n.º 1: filtra silicio y lleva 2 tarjetas de aceleración.
        <Row><ItemImage id="silicon" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="4.3 3 1" thickness=".05">
(4) Bus de exportación n.º 2: filtra lingotes de oro y lleva 2 tarjetas de aceleración.
        <Row><ItemImage id="minecraft:gold_ingot" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="4.3 4 1" thickness=".05">
(5) Bus de exportación n.º 3: filtra cristales de cuarzo Certus y lleva 2 tarjetas de aceleración.
        <Row><ItemImage id="certus_quartz_crystal" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 6 0" max="4.3 5 1" thickness=".05">
(6) Bus de exportación n.º 4: filtra diamantes y lleva 2 tarjetas de aceleración.
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 0" max="2 2 1" thickness=".05">
(7) Bus de exportación n.º 5: filtra polvo de redstone y lleva 2 tarjetas de aceleración.
        <Row><ItemImage id="minecraft:redstone" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="3 2 1" thickness=".05">
(8) Prensador n.º 1: configuración predeterminada, molde de silicio y 4 tarjetas de aceleración.
        <Row><ItemImage id="silicon_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 3 0" max="3 4 1" thickness=".05">
(9) Prensador n.º 2: configuración predeterminada, molde de procesador lógico y 4 tarjetas de aceleración.
        <Row><ItemImage id="logic_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="3 5 1" thickness=".05">
(10) Prensador n.º 3: configuración predeterminada, molde de procesador de cálculo y 4 tarjetas de aceleración.
        <Row><ItemImage id="calculation_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="3 6 1" thickness=".05">
(11) Prensador n.º 4: configuración predeterminada, molde de procesador de ingeniería y 4 tarjetas de aceleración.
        <Row><ItemImage id="engineering_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 0" max="1 3 1" thickness=".05">
(12) Prensador n.º 5: configuración predeterminada y 4 tarjetas de aceleración.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 2 0" max="3 1 1" thickness=".05">
(13) Bus de importación n.º 1: configuración predeterminada y 2 tarjetas de aceleración.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 4 0" max="3 3 1" thickness=".05">
(14) Bus de importación n.º 2: configuración predeterminada y 2 tarjetas de aceleración.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 5 0" max="3 4 1" thickness=".05">
(15) Bus de importación n.º 3: configuración predeterminada y 2 tarjetas de aceleración.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 6 0" max="3 5 1" thickness=".05">
(16) Bus de importación n.º 4: configuración predeterminada y 2 tarjetas de aceleración.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 3 0" max="1 3.3 1" thickness=".05">
(17) Bus de almacenamiento n.º 2: configuración predeterminada.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1.7 0" max="1 2 1" thickness=".05">
(18) Bus de almacenamiento n.º 3: configuración predeterminada.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 0" max="0.7 3 1" thickness=".05">
(19) Bus de importación n.º 5: configuración predeterminada y 2 tarjetas de aceleración.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="5 0.7 0" max="6 1 1" thickness=".05">
(20) Bus de almacenamiento n.º 4: configuración predeterminada.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.3 2.7 0.3" max="3.7 3 0.7" thickness=".05">
La fibra de cuarzo alimenta los 3 prensadores porque estos actúan como cables y transmiten energía.
  </BoxAnnotation>

<DiamondAnnotation pos="7 1.5 0.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="185" pitch="5" />
</GameScene>

## Configuraciones

* El <ItemLink id="pattern_provider" /> (1) tiene la configuración predeterminada y los <ItemLink id="processing_pattern" /> correspondientes.

![Patrón de procesador lógico](../assets/diagrams/logic_pattern.png)
![Patrón de procesador de cálculo](../assets/diagrams/calculation_pattern.png)
![Patrón de procesador de ingeniería](../assets/diagrams/engineering_pattern.png)

* Los <ItemLink id="storage_bus" /> (2, 17, 18 y 20) tienen la configuración predeterminada.
* Los <ItemLink id="export_bus" /> (3-7) filtran su ingrediente correspondiente y llevan 2 <ItemLink id="speed_card" />.
    <Row>
      <ItemImage id="silicon" scale="2" />
      <ItemImage id="minecraft:gold_ingot" scale="2" />
      <ItemImage id="certus_quartz_crystal" scale="2" />
      <ItemImage id="minecraft:diamond" scale="2" />
      <ItemImage id="minecraft:redstone" scale="2" />
    </Row>
* Los <ItemLink id="import_bus" /> (13-16 y 19) tienen la configuración predeterminada y llevan 2 <ItemLink id="speed_card" />.
* Los <ItemLink id="inscriber" /> tienen la configuración predeterminada, su [molde](../items-blocks-machines/presses.md) correspondiente y 4 <ItemLink id="speed_card" />.
   <Row>
     <ItemImage id="silicon_press" scale="2" />
     <ItemImage id="logic_processor_press" scale="2" />
     <ItemImage id="calculation_processor_press" scale="2" />
     <ItemImage id="engineering_processor_press" scale="2" />
   </Row>

## Funcionamiento

1. El <ItemLink id="pattern_provider" /> envía los ingredientes al barril.
2. La primera [subred tipo tubería](pipe-subnet.md), naranja, extrae el silicio, la redstone y el ingrediente del procesador —lingote de oro, cristal de cuarzo Certus o diamante— y los introduce en el <ItemLink id="inscriber" /> correspondiente.
3. Los cuatro primeros <ItemLink id="inscriber" /> producen <ItemLink id="printed_silicon" /> y <ItemLink id="printed_logic_processor" />, <ItemLink id="printed_calculation_processor" /> o <ItemLink id="printed_engineering_processor" />.
4. La segunda y tercera [subred tipo tubería](pipe-subnet.md), verdes, llevan los circuitos impresos de esos cuatro <ItemLink id="inscriber" /> al quinto <ItemLink id="inscriber" />, que hace el ensamblaje final.
5. El quinto <ItemLink id="inscriber" /> ensambla el [procesador](../items-blocks-machines/processors.md).
6. La cuarta [subred tipo tubería](pipe-subnet.md), morada, lo introduce en el proveedor y lo devuelve a la red principal.