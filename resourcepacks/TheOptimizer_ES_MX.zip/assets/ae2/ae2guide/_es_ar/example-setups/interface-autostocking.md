---
navigation:
  parent: example-setups/example-setups-index.md
  title: Reposición automática con una interfaz
  icon: interface
---

# Reposición automática con una interfaz

Quizá te preguntes: «¿Cómo mantengo una reserva de varios objetos y crafteo más cuando hagan falta?».

Una solución es combinar una <ItemLink id="interface" /> con una <ItemLink id="crafting_card" /> para pedir objetos al [autocrafteo](../ae2-mechanics/autocrafting.md) de la red. Sirve especialmente para mantener cantidades pequeñas de muchos objetos distintos.

El ejemplo está recortado para que no sea demasiado ancho. Lo más eficiente suele ser usar 4 <ItemLink id="interface" /> y 4 <ItemLink id="storage_bus" /> para aprovechar los 8 [canales](../ae2-mechanics/channels.md) de un [cable](../items-blocks-machines/cables.md) normal.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_autostocking.snbt" />

<BoxAnnotation color="#dddddd" min="0 0 0" max="2 1 1">
(1) Interfaces: mantienen los objetos deseados en sus inventarios y llevan tarjetas de crafteo.
        <ItemImage id="crafting_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="2 1.3 1">
(2) Buses de almacenamiento: «Modo de entrada/salida» en «Solo extracción».
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* Configura los objetos deseados en las ranuras superiores de las <ItemLink id="interface" /> (1), haciendo click con el objeto o arrastrándolo desde JEI. Ajusta la cantidad con la llave sobre esas ranuras. Deben llevar <ItemLink id="crafting_card" />.
* En los <ItemLink id="storage_bus" /> (2), establece «Modo de entrada/salida» en «Solo extracción».

## Funcionamiento

1. Si una <ItemLink id="interface" /> no consigue suficientes objetos del [almacenamiento de red](../ae2-mechanics/import-export-storage.md) y tiene una <ItemLink id="crafting_card" />, solicita al [autocrafteo](../ae2-mechanics/autocrafting.md) que produzca más.
2. Los <ItemLink id="storage_bus" /> permiten a la red acceder al contenido de las interfaces.