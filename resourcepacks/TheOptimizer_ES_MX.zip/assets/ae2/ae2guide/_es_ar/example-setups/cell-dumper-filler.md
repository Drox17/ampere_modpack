---
navigation:
  parent: example-setups/example-setups-index.md
  title: Vaciador o llenador de celdas
  icon: io_port
---

# Vaciador o llenador de celdas

Quizá te preguntes: «¿Cómo vacío rápidamente una celda en un cofre, un conjunto de cajones o una mochila, o cómo la lleno desde ellos?».

Usa un <ItemLink id="io_port" /> y una subred que limite dónde puede depositar o de dónde puede extraer los objetos.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/cell_dumper_filler.snbt" />

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 1">
(1) Puerto de E/S: el botón con flecha del centro alterna entre «Transferir datos a la red» y «Transferir datos a la celda». Lleva 3 tarjetas de aceleración.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0.7 0" max="1 1 1">
(2) Bus de almacenamiento: configuración predeterminada.
  </BoxAnnotation>

<BoxAnnotation color="#33dd33" min="0 1 0" max="1 2 1">
Coloca aquí lo que quieras llenar o vaciar.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0.35 0.35" max="2.3 0.65 0.65">
Fibra de cuarzo: solo hace falta si otra red suministra la energía.
  </BoxAnnotation>

<DiamondAnnotation pos="3 0.5 0.5" color="#00ff00">
Hacia una fuente de energía, como otra red o un receptor de energía.
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* El <ItemLink id="io_port" /> (1) alterna entre «Transferir datos a la red» y «Transferir datos a la celda» con la flecha central de su interfaz. Lleva 3 tarjetas de aceleración para alcanzar la velocidad máxima.
* El <ItemLink id="storage_bus" /> (2) tiene la configuración predeterminada.

## Funcionamiento

### En modo «Transferir a la red»

1. El <ItemLink id="io_port" /> intenta vaciar la [celda de almacenamiento](../items-blocks-machines/storage_cells.md) introducida en el [almacenamiento de red](../ae2-mechanics/import-export-storage.md).
2. El único almacenamiento de la subred es el <ItemLink id="storage_bus" />, que deposita los objetos, fluidos u otros materiales en el contenedor que coloques delante.
* La <ItemLink id="energy_cell" /> aporta suficiente reserva de [energía](../ae2-mechanics/energy.md) para evitar que la red se agote al transferir tantos objetos por tick.

### En modo «Transferir a la celda de almacenamiento»

1. El <ItemLink id="io_port" /> intenta vaciar el [almacenamiento de red](../ae2-mechanics/import-export-storage.md) en la [celda de almacenamiento](../items-blocks-machines/storage_cells.md) introducida.
2. El único almacenamiento de la subred es el <ItemLink id="storage_bus" />, que extrae los objetos, fluidos u otros materiales del contenedor que coloques delante.
* La <ItemLink id="energy_cell" /> aporta suficiente reserva de [energía](../ae2-mechanics/energy.md) para evitar que la red se agote al transferir tantos objetos por tick.