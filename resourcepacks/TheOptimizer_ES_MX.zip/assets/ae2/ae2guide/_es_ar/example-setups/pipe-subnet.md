---
navigation:
  parent: example-setups/example-setups-index.md
  title: Subred como «tubería» de objetos y fluidos
  icon: storage_bus
---

# Subred como «tubería» de objetos y fluidos

Una forma sencilla de imitar una tubería de objetos o fluidos con [dispositivos](../ae2-mechanics/devices.md) de AE2. Sirve para los mismos usos que cualquier tubería, incluido devolver resultados de crafteo a un <ItemLink id="pattern_provider" />.

Hay dos métodos principales:

## Bus de importación → bus de almacenamiento

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
(1) Bus de importación: admite filtros.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
(2) Bus de almacenamiento: admite filtros. Este y los demás buses de destino deben ser el único almacenamiento de la red.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
Origen
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
Destino
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

El <ItemLink id="import_bus" /> (1) extrae objetos o fluidos del inventario de origen e intenta guardarlos en el [almacenamiento de red](../ae2-mechanics/import-export-storage.md). Como el único almacenamiento es el <ItemLink id="storage_bus" /> (2), los deposita en el inventario de destino. Por eso debe ser una subred separada de la principal. Una <ItemLink id="quartz_fiber" /> suministra la energía. Ambos buses admiten filtros; sin ellos, transfieren todo lo accesible. También puedes usar varios buses de importación y de almacenamiento.

## Bus de almacenamiento → bus de exportación

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
(1) Bus de almacenamiento: admite filtros. Este y los demás buses de origen deben ser el único almacenamiento de la red.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
(2) Bus de exportación: necesita un filtro.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
Origen
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
Destino
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

El <ItemLink id="export_bus" /> del destino intenta extraer los objetos de su filtro del [almacenamiento de red](../ae2-mechanics/import-export-storage.md). Como el único almacenamiento es el <ItemLink id="storage_bus" />, los extrae del inventario de origen. Por eso debe ser una subred separada de la principal. Una <ItemLink id="quartz_fiber" /> suministra la energía. El bus de exportación necesita un filtro para funcionar. También puedes usar varios buses de almacenamiento y de exportación.

## Una instalación que no funciona (bus de importación → bus de exportación)

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_export_pipe.snbt" />

<BoxAnnotation color="#dd3333" min="3.7 0 0" max="4 1 1">
Bus de importación: la red no tiene almacenamiento donde introducir los objetos.
  </BoxAnnotation>

<BoxAnnotation color="#dd3333" min="1 0 0" max="1.3 1 1">
(2) Bus de exportación: la red no tiene almacenamiento del que extraer objetos.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#ff0000">
Origen
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#ff0000">
Destino
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Una instalación con solo un bus de importación y otro de exportación no funciona. El primero intenta llevar contenido del origen al almacenamiento de red; el segundo intenta retirarlo de ese almacenamiento y enviarlo al destino. Como **la red no tiene almacenamiento**, ninguno puede hacer su trabajo y no ocurre nada.

## Entrada y salida por una sola cara

Supón que una máquina admite entradas y extracción de resultados por la misma cara, como un <ItemLink id="charger" />. Puedes introducir ingredientes y retirar resultados combinando los dos métodos anteriores:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="4 1 1" max="5 1.3 2">
(1) Bus de importación: admite filtros.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
(2) Bus de almacenamiento: admite filtros. Este y los demás buses para insertar o extraer deben ser el único almacenamiento de la red.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
(3) Máquina en la que quieres insertar y extraer: aquí, un cargador.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 1" max="1 1.3 2">
(4) Bus de exportación: necesita un filtro.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 1.5" color="#00ff00">
Origen
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 1.5" color="#00ff00">
Destino
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Interfaces

Hay otros [dispositivos](../ae2-mechanics/devices.md), además de los buses de importación y exportación, que insertan y extraen del [almacenamiento de red](../ae2-mechanics/import-export-storage.md). La <ItemLink id="interface" /> es uno de ellos. Si recibe algo que no debe mantener en reserva, lo envía al almacenamiento de red, como el método bus de importación → bus de almacenamiento. Si tiene una reserva configurada, extrae del almacenamiento, como el método bus de almacenamiento → bus de exportación. Puedes reservar algunos objetos y dejar pasar otros para insertar y extraer a distancia mediante buses de almacenamiento, si lo necesitas.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/interface_pipes.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
Interfaz ME
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
Bus de almacenamiento ME
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.7 0 2" max="4 1 3">
Bus de almacenamiento ME
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 2" max="1 1.3 3">
Bus de almacenamiento ME
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## De uno a varios, de varios a uno y de varios a varios

Por supuesto, no estás limitado a un solo <ItemLink id="import_bus" />, <ItemLink id="export_bus" /> o <ItemLink id="storage_bus" />.

<GameScene zoom="3" background="transparent">
<ImportStructure src="../assets/assemblies/many_to_many_pipe.snbt" />

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## Abastecer varios destinos

Con todo esto podemos enviar ingredientes desde una sola cara de un <ItemLink id="pattern_provider" /> hacia varios destinos: varias máquinas o varias caras de una misma máquina.

No sirve una tubería importación → almacenamiento ni almacenamiento → exportación, porque el <ItemLink id="pattern_provider" /> nunca contiene los ingredientes. Los *envía* a inventarios adyacentes, así que necesitamos un inventario adyacente que también pueda importar objetos.

Eso suena a… ¡una <ItemLink id="interface" />! Usa un proveedor direccional o plano y/o una interfaz plana para evitar que ambos unan sus redes.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
Interfaz: debe ser plana, no de bloque completo.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
Buses de almacenamiento
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
Destinos de los ingredientes del patrón: varias máquinas o varias caras de una máquina.
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>