---
navigation:
  parent: example-setups/example-setups-index.md
  title: Extractor automático de minerales con Fortuna
  icon: minecraft:raw_iron
---

# Extracción automática de minerales con Fortuna

El <ItemLink id="annihilation_plane" /> admite cualquier encantamiento de pico, incluido Fortuna. Una aplicación evidente es combinar varios con Fortuna y varios <ItemLink id="formation_plane" /> para colocar y romper minerales rápidamente con los <ItemLink id="annihilation_plane" />.

Los <ItemLink id="import_bus" /> aceleran progresivamente: la instalación empieza despacio y alcanza la velocidad máxima en unos segundos.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 2" max="3 1 3">
(1) Bus de importación: lleva varias tarjetas de aceleración.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 2" max="2 1 2.3">
(2) Planos de formación: configuración predeterminada.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0.7" max="2 1 1">
(3) Planos de aniquilación: no tienen interfaz de configuración y llevan Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 0" max="3 1 1">
(4) Bus de almacenamiento: configuración predeterminada.
  </BoxAnnotation>

<DiamondAnnotation pos="3.5 0.5 2.5" color="#00ff00">
Entrada
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 0.5 0.5" color="#00ff00">
Salida
    </DiamondAnnotation>

<DiamondAnnotation pos="4 0.5 1.5" color="#00ff00">
Hacia la red principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configuraciones

* El <ItemLink id="import_bus" /> (1) lleva varias <ItemLink id="speed_card" />. Cuantos más planos haya, más tarjetas necesitará para extraer más objetos por operación.
* Los <ItemLink id="formation_plane" /> (2) tienen la configuración predeterminada.
* Los <ItemLink id="annihilation_plane" /> (3) no tienen interfaz de configuración y llevan Fortuna.
* El <ItemLink id="storage_bus" /> (4) tiene la configuración predeterminada.

## Funcionamiento

1. El <ItemLink id="import_bus" /> de la subred verde importa bloques del primer barril al [almacenamiento de red](../ae2-mechanics/import-export-storage.md).
2. Su único almacenamiento es el <ItemLink id="formation_plane" />, que coloca los bloques.
3. El <ItemLink id="annihilation_plane" /> de la subred naranja los rompe con Fortuna.
4. El <ItemLink id="storage_bus" /> de esa subred guarda los resultados en el segundo barril.
