---
navigation:
  title: Índice
  position: 0
---
# ¿Qué es Applied Energistics 2?

# Cómo usar esta guía

* Abre la barra lateral izquierda para consultar el índice.
* Muchas páginas tienen escenas interactivas. Si ves los botones ![Más](assets/diagrams/plus.png) y ![Menos](assets/diagrams/minus.png) de zoom, puedes mover la cámara: arrastra con click izquierdo para girarla y con click derecho para desplazarla.

# ¿Qué es Applied Energistics 2?

Applied Energistics 2 añade componentes y mecánicas de logística y almacenamiento. Puedes sustituir tu enorme sala de cofres por una red ME compacta, pero eso es solo el comienzo. Está diseñado para trabajar con otros mods y automatizarlos. Con un click puedes craftear todos los componentes y el resultado final de una cadena compleja, mantener cantidades en reserva produciendo más cuando hagan falta o simplemente mover objetos por la base.

* [Primeros pasos](getting-started.md)
* [Consejos y trucos](tips-and-tricks.md)
* [Mecánicas de AE2](ae2-mechanics/ae2-mechanics-index.md)
* [Ejemplos de instalaciones](example-setups/example-setups-index.md)
* [Objetos, bloques y máquinas](items-blocks-machines/items-blocks-machines-index.md)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>