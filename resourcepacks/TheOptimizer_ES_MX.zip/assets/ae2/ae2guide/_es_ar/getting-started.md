---
navigation:
  title: Primeros pasos (1.20+)
  position: 10
---

<div class="notification is-info">
Esta información solo corresponde a Applied Energistics 2 para Minecraft 1.20 y versiones posteriores.
</div>

# Primeros pasos

## Materiales iniciales

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assets/assemblies/meteor_interior.snbt" />
</GameScene>

Para empezar con Applied Energistics 2, busca un [meteorito](ae2-mechanics/meteorites.md). Son bastante comunes y dejan enormes cráteres, así que probablemente hayas visto alguno. Si no, craftea una <ItemLink id="meteorite_compass" />: señala el <ItemLink id="mysterious_cube" /> más cercano.

Mina hacia el centro del meteorito. Encontrarás cúmulos y brotes de cuarzo Certus, [drusas](items-blocks-machines/budding_certus.md) de varios estados y un cubo misterioso en el centro.

Recoge los cúmulos y bloques de cuarzo Certus. También puedes recoger las drusas, pero sin Toque de seda se deterioran 1 nivel.

No rompas las drusas perfectas: incluso con Toque de seda pasan a ser imperfectas, y no se pueden reparar hasta recuperar el estado perfecto.

Rompe también el cubo misterioso del centro para obtener los 4 moldes del prensador.

## Cultivar cuarzo Certus

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Los brotes de cuarzo Certus crecen en las [drusas de cuarzo Certus](items-blocks-machines/budding_certus.md), de forma parecida a la amatista. Si rompes un brote antes de que termine de crecer, soltará un <ItemLink id="certus_quartz_dust" />, sin que Fortuna cambie la cantidad. Un cúmulo maduro suelta cuatro <ItemLink id="certus_quartz_crystal" />, y Fortuna aumenta esa cantidad.

Hay 4 estados de las drusas de cuarzo Certus: perfecta, imperfecta, astillada y dañada.

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_blocks.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Cada vez que un brote avanza una etapa, la drusa puede deteriorarse un nivel hasta convertirse en un bloque de cuarzo Certus normal. Puedes repararla, o crear una nueva, lanzando al agua la drusa o un bloque de cuarzo Certus junto con uno o más <ItemLink id="charged_certus_quartz_crystal" />.

<RecipeFor id="damaged_budding_quartz" />

Las drusas perfectas no se deterioran y producen cuarzo Certus indefinidamente. Sin embargo, no se pueden craftear ni mover con un pico, ni siquiera con Toque de seda. Aunque *sí* puedes moverlas mediante el [almacenamiento espacial](ae2-mechanics/spatial-io.md).

Los brotes de cuarzo Certus crecen muy despacio por sí solos. Por suerte, un <ItemLink id="growth_accelerator" /> junto a la drusa acelera enormemente el proceso. Tu primera prioridad debería ser construir unos cuantos.

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_2.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Si no tienes suficiente cuarzo para crear también un <ItemLink id="energy_acceptor" /> o una <ItemLink id="vibration_chamber" />, puedes colocar una <ItemLink id="crank" /> en el extremo del acelerador.

[Aquí se explica](example-setups/simple-certus-farm.md) cómo cosechar cuarzo Certus automáticamente.

## Una aclaración sobre el Fluix

También necesitarás Fluix, que ya habrás usado para los aceleradores de crecimiento. Se obtiene lanzando al agua cuarzo Certus cargado, redstone y cuarzo del Nether. Automatizarlo «queda como ejercicio para el lector».

Si aún no tienes uno, necesitarás un <ItemLink id="charger" /> para producir <ItemLink id="charged_certus_quartz_crystal" />.

## Prensar algunos procesadores

Al romper el cubo misterioso del meteorito habrás conseguido cuatro «moldes». Se usan en el <ItemLink id="inscriber" /> para producir los tres tipos de procesador.

<ItemGrid>
  <ItemIcon id="silicon_press" />

  <ItemIcon id="logic_processor_press" />

  <ItemIcon id="calculation_processor_press" />

  <ItemIcon id="engineering_processor_press" />
</ItemGrid>

El prensador tiene acceso por caras, como el horno vanilla. Introducir por arriba o abajo lleva a la ranura superior o inferior; por los lados o por detrás lleva a la central. Los resultados se extraen por los lados o por detrás.

Puedes girar los prensadores con una <ItemLink id="certus_quartz_wrench" /> para facilitar el uso de tolvas y, quizá, reducir el espagueti de tuberías.

Produce algunos procesadores de cada tipo para el siguiente paso: construir un sistema ME básico. Automatizar los procesadores «queda como ejercicio para el lector».

## Tecnología Matter Energy: redes y almacenamiento ME

### ¿Qué es el almacenamiento ME?

ME son las siglas de Matter Energy, «materia y energía», y se pronuncia «eme e».

Matter Energy es la base de Applied Energistics 2: imagina un cofre multibloque diseñado por un científico loco, capaz de revolucionar tu almacenamiento. Es muy distinto de otros sistemas de Minecraft y requiere pensar de otra manera. Pero, una vez que lo dominas, guardar enormes cantidades en poco espacio y acceder desde varias terminales son solo la punta del iceberg.

### ¿Qué necesito saber para empezar?

ME guarda objetos dentro de otros objetos llamados [celdas de almacenamiento](items-blocks-machines/storage_cells.md). Hay 5 tamaños de capacidad creciente. Para usarlas, colócalas en un <ItemLink id="chest" /> o una <ItemLink id="drive" />.

El <ItemLink id="chest" /> muestra el contenido de la celda en cuanto la insertas. Puedes guardar y retirar objetos como en un <ItemLink id="minecraft:chest" /> normal, pero realmente se guardan en la celda, no en el propio <ItemLink id="chest" />.

El <ItemLink id="chest" /> sirve para conocer ME, pero para aprovecharlo de verdad necesitas una [red ME](ae2-mechanics/me-network-connections.md).

## Tu primer sistema ME

Con los materiales y máquinas básicos ya puedes construir tu primer sistema ME. Será sencillo: sin autocrafteo ni logística, solo un almacenamiento cómodo donde buscar objetos.

<GameScene zoom="6" interactive={true}>
<ImportStructure src="assets/assemblies/tiny_me_system.snbt" />

</GameScene>

* Necesitas:
    * 1x <ItemLink id="drive" />.
    * 1x <ItemLink id="terminal" /> o <ItemLink id="crafting_terminal" />.
    * 1x <ItemLink id="energy_acceptor" />.
    * Algunos [cables](items-blocks-machines/cables.md) de vidrio, recubiertos o inteligentes, pero no densos.
    * Algunas [celdas de almacenamiento](items-blocks-machines/storage_cells.md). Las de 4k ofrecen un buen equilibrio entre capacidad y tipos. Sería más eficiente [particionar](items-blocks-machines/cell_workbench.md) una combinación de 4k y 1k, pero dejaremos eso para más adelante.
---
1. Coloca la unidad ME.
2. El receptor de energía y otros [dispositivos](ae2-mechanics/devices.md) de AE2 tienen 2 variantes: bloque y plana. Puedes alternarlas en una cuadrícula de crafteo. Pon el bloque junto a la unidad; si es plano, coloca un cable sobre la unidad y el receptor en ese cable.
3. Aliméntalo con el cable, tubería o conducto de tu mod de energía favorito.
4. Coloca un cable sobre la unidad, o a la altura de tus ojos, y monta la terminal encima.
5. Introduce las celdas en la unidad.
6. Disfruta del resultado.
7. Juega con los ajustes de la terminal.
8. Contempla tu poder y habilidad absolutos.
9. Date cuenta de que, en realidad, esta red es bastante pequeña.

### Ampliar la red

Ya tienes almacenamiento básico y acceso a él. Es un buen comienzo, pero probablemente quieras automatizar algún procesamiento.

Por ejemplo, pon un <ItemLink id="export_bus" /> sobre un horno para introducir minerales y un <ItemLink id="import_bus" /> debajo para recoger lo fundido.

El <ItemLink id="export_bus" /> lleva objetos de la red al inventario conectado; el <ItemLink id="import_bus" /> hace el recorrido inverso.

### Superar los límites

Probablemente ya estés cerca de los 8 [dispositivos](ae2-mechanics/devices.md). Al llegar a 9 tendrás que gestionar los [canales](ae2-mechanics/channels.md). Muchos dispositivos, aunque no todos, necesitan uno para funcionar.

La red admite 8 canales por defecto. Para superar ese límite, añade un <ItemLink id="controller" />: podrás ampliarla mucho más. Los [cables inteligentes](items-blocks-machines/cables.md) muestran las rutas de los canales. Úsalos al principio para entender su funcionamiento, o si te sobra redstone y piedra luminosa.
