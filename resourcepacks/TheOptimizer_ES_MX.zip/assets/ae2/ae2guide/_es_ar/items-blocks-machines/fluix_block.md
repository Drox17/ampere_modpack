---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bloque de Fluix
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# Bloque de Fluix

<BlockImage id="fluix_block" scale="8" />

Bloque de almacenamiento de <ItemLink id="fluix_crystal" />. También se usa en recetas de algunas máquinas.

## Receta

<RecipeFor id="fluix_block" />
