---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Unidad ME
  icon: drive
  position: 210
categories:
- devices
item_ids:
- ae2:drive
---

# Unidad ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/drive.snbt" />
</GameScene>

La unidad ME es el [dispositivo](../ae2-mechanics/devices.md) donde introduces las [celdas de almacenamiento](storage_cells.md) para usarlas como [almacenamiento de red](../ae2-mechanics/import-export-storage.md). Tiene 10 ranuras de una celda cada una.

Si lo necesitas, puedes insertar y retirar las celdas con tolvas, buses de AE2 u otros sistemas de logística.

Puedes girarlo con una <ItemLink id="certus_quartz_wrench" />.

## Indicadores LED del estado de las celdas

El indicador LED de cada celda muestra su estado:

| Color | Estado |
| :--- | :--- |
| Verde | Vacía |
| Azul | Contiene datos |
| Naranja | Límite de [tipos](../ae2-mechanics/bytes-and-types.md) alcanzado: no admite tipos nuevos |
| Rojo | [Bytes](../ae2-mechanics/bytes-and-types.md) llenos: no admite más objetos |
| Negro | Sin energía o sin [canal](../ae2-mechanics/channels.md) |

## Prioridad

Ajusta la prioridad con la llave de la esquina superior derecha. Los objetos entran primero al almacenamiento de mayor prioridad. Si varios almacenamientos o celdas tienen la misma, se prefiere el que ya contiene el objeto. Una celda [particionada](cell_workbench.md) cuenta como si ya contuviera los objetos de su filtro. La extracción empieza por la prioridad más baja. Así, insertar y retirar contenido tiende a llenar los almacenamientos prioritarios y vaciar los de menor prioridad.

## Receta

<RecipeFor id="drive" />
