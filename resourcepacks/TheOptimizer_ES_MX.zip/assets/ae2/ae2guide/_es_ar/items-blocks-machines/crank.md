---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Manivela de madera
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# Manivela de madera

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

La manivela alimenta máquinas cuando aún no tienes otra fuente de energía o un <ItemLink id="energy_acceptor" />. Los apuros del comienzo, ¿verdad?

## Receta

<RecipeFor id="crank" />
