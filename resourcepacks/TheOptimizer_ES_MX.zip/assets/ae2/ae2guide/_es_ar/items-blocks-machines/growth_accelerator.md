---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Acelerador de crecimiento
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# Acelerador de crecimiento

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

Junto a una drusa, el acelerador aumenta enormemente el [crecimiento](../ae2-mechanics/certus-growth.md) de cuarzo Certus o amatista.

Curiosamente, *también* acelera el crecimiento de varias plantas.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Para alimentarlo a mano, coloca una <ItemLink id="crank" /> arriba o abajo y haz click derecho.

Solo conecta cables por los extremos que tienen detalles de Fluix rosa.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Receta

<RecipeFor id="growth_accelerator" />
