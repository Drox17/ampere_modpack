---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cuchillos de corte
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# Herramientas de cuarzo

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

Los cuchillos de corte sirven para crear <ItemLink id="name_press" /> y <ItemLink id="cable_anchor" />.

Para crear un molde de nombres, haz click derecho con el cuchillo e introduce un lingote de metal. Escribe el nombre deseado y retira el molde terminado.

## Recetas

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>
