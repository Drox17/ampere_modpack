---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cofre ME
  icon: chest
  position: 210
categories:
- devices
item_ids:
- ae2:chest
---

# Cofre ME

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/chest.snbt" />
</GameScene>

El cofre ME equivale a una pequeña red con <ItemLink id="terminal" />, <ItemLink id="drive" /> y <ItemLink id="energy_acceptor" />. Puede servir como sistema mínimo, pero su única [celda de almacenamiento](../items-blocks-machines/storage_cells.md) limita su utilidad.

Su principal utilidad es acceder específicamente a la celda que contiene. La terminal integrada solo muestra esa celda; los [dispositivos](../ae2-mechanics/devices.md) del resto de la red acceden a todo el [almacenamiento de red](../ae2-mechanics/import-export-storage.md), incluidos los cofres ME.

Tiene 2 interfaces y acceso de objetos según la cara. La cara superior abre la terminal integrada y permite introducir objetos en la celda, pero no extraerlos. Las demás caras abren la interfaz de la ranura de celda y la prioridad. Los sistemas automáticos solo insertan y retiran la celda por la cara que muestra su ranura.

Puedes girarlo con una <ItemLink id="certus_quartz_wrench" />.

Su reserva interna de AE es pequeña. Si no comparte red con una [celda de energía](../items-blocks-machines/energy_cells.md), insertar o extraer demasiados objetos a la vez puede dejarlo sin energía.

Puedes cambiar el color de la terminal con un <ItemLink id="color_applicator" />.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/chest_color.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Ajustes

Tiene los mismos ajustes que una <ItemLink id="terminal" /> o una <ItemLink id="crafting_terminal" />, pero no admite <ItemLink id="view_cell" />.

## Indicadores LED del estado de las celdas

El indicador LED de la celda muestra su estado:

| Color | Estado |
| :--- | :--- |
| Verde | Vacía |
| Azul | Contiene datos |
| Naranja | Límite de [tipos](../ae2-mechanics/bytes-and-types.md) alcanzado: no admite tipos nuevos |
| Rojo | [Bytes](../ae2-mechanics/bytes-and-types.md) llenos: no admite más objetos |
| Negro | Sin energía o sin [canal](../ae2-mechanics/channels.md) |

## Prioridad

Ajusta la prioridad con la llave de la esquina superior derecha de la interfaz de la celda. Los objetos entran primero al almacenamiento de mayor prioridad. Si varios almacenamientos o celdas tienen la misma prioridad, se prefiere el que ya contiene el objeto. Una celda [particionada](cell_workbench.md) cuenta como si ya contuviera los objetos de su filtro. Al extraer se empieza por la prioridad más baja. Así, insertar y retirar objetos tiende a llenar los almacenamientos prioritarios y vaciar los de menor prioridad.

## Receta

<RecipeFor id="chest" />
