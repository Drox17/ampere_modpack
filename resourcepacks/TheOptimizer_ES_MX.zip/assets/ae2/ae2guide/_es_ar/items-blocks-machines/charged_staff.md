---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bastón cargado
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# Bastón cargado

<ItemImage id="charged_staff" scale="4" />

El bastón cargado es un palo con un <ItemLink id="charged_certus_quartz_crystal" /> en la punta. Inflige 6 de daño y consume 300 AE por ataque.

Se recarga en un <ItemLink id="charger" />.

## Receta

<RecipeFor id="charged_staff" />
