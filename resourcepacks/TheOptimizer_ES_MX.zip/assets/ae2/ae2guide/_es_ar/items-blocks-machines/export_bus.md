---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bus de exportación ME
  icon: export_bus
  position: 220
categories:
- devices
item_ids:
- ae2:export_bus
---

# Bus de exportación ME

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/export_bus.snbt" />
</GameScene>

El bus de exportación retira objetos y fluidos, y otros materiales con los complementos adecuados, del [almacenamiento de red](../ae2-mechanics/import-export-storage.md) y los introduce en el inventario que toca.

Para reducir el lag, entra en una especie de reposo si no ha exportado recientemente. Al conseguir exportar algo, despierta y acelera hasta 4 operaciones por segundo.

Son [componentes de cable](../ae2-mechanics/cable-subparts.md).

## Filtrado

Por defecto no exporta nada. Los objetos de las ranuras de filtro forman una lista de permitidos: solo esos pueden exportarse.

Puedes arrastrar objetos y fluidos de JEI/REI a las ranuras aunque no los tengas.

Haz click derecho con un contenedor de fluidos, como un cubo o tanque, para filtrar su contenido en vez del propio contenedor.

## Mejoras

El bus admite estas [mejoras](upgrade_cards.md):

* <ItemLink id="capacity_card" />: añade ranuras de filtro y un ajuste para elegir el orden de exportación.
* <ItemLink id="speed_card" />: aumenta la cantidad transferida por operación.
* <ItemLink id="fuzzy_card" />: filtra por daño y/o ignora el NBT.
* <ItemLink id="crafting_card" />: solicita objetos al [autocrafteo](../ae2-mechanics/autocrafting.md). Puede usar primero las existencias o solicitar siempre un crafteo nuevo.
* <ItemLink id="redstone_card" />: activa con señal, sin señal o una vez por pulso.

## Velocidades

| Tarjetas de aceleración | Objetos por operación |
| --- | --- |
| 0 | 1 |
| 1 | 8 |
| 2 | 32 |
| 3 | 64 |
| 4 | 96 |

## Receta

<RecipeFor id="import_bus" />
