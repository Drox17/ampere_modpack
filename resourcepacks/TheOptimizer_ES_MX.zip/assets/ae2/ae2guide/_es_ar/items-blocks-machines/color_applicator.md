---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Aplicador de color
  icon: color_applicator
  position: 410
categories:
- tools
item_ids:
- ae2:color_applicator
---

# Aplicador de color

<ItemImage id="color_applicator" scale="4" />

El aplicador pinta bloques como [cables](cables.md), lana, terracota, vidrio y concreto. Consume [bolas de pintura](paintballs.md) o tintes. Las bolas de nieve quitan el color de los cables y las manchas de pintura de los bloques.

Se recarga en un <ItemLink id="charger" />.

Funciona como una [celda de almacenamiento](storage_cells.md). La forma más sencilla de cargar su pintura es introducirlo en la ranura de celda de un <ItemLink id="chest" />.

Haz click derecho para aplicar color y Shift + rueda del mouse para alternar entre las pinturas y tintes almacenados.

## Mejoras

Admite estas [mejoras](upgrade_cards.md), que se añaden mediante una <ItemLink id="cell_workbench" />:

* <ItemLink id="equal_distribution_card" />: reparte los bytes equitativamente entre los tipos para que uno no llene toda la celda.
* <ItemLink id="void_card" />: destruye los objetos entrantes si la celda está llena, o si se llena el espacio asignado a ese tipo con distribución equitativa. ¡Cuidado con el filtro de particionado!
* <ItemLink id="energy_card" />: aumenta la capacidad de la batería.

## Receta

<RecipeFor id="color_applicator" />
