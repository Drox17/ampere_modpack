---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Paneles iluminados
  icon: semi_dark_monitor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:monitor
- ae2:semi_dark_monitor
- ae2:dark_monitor
---

# Paneles iluminados

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/illuminated_panels.snbt" />
  <IsometricCamera yaw="-75" pitch="30" />
</GameScene>

Los paneles iluminados son fuentes de luz decorativas y un ingrediente de las [terminales](terminals.md).

Son [componentes de cable](../ae2-mechanics/cable-subparts.md).

## Recetas

<Row>
  <RecipeFor id="monitor" />

  <RecipeFor id="semi_dark_monitor" />

  <RecipeFor id="dark_monitor" />
</Row>
