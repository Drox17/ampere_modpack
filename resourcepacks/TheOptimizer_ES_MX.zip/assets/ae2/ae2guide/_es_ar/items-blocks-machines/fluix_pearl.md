---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Perla de Fluix
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Perla de Fluix

<ItemImage id="fluix_pearl" scale="4" />

Una perla de ender recubierta de <ItemLink id="fluix_crystal" />, utilizada para producir varios componentes de AE2.

## Receta

<RecipeFor id="fluix_pearl" />
