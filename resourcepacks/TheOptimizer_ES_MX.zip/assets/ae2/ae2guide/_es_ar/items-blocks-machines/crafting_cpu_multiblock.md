---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: CPU de crafteo multibloque (almacenamiento, coprocesador, monitor y unidad)
  icon: 1k_crafting_storage
  position: 210
categories:
- devices
item_ids:
- ae2:1k_crafting_storage
- ae2:4k_crafting_storage
- ae2:16k_crafting_storage
- ae2:64k_crafting_storage
- ae2:256k_crafting_storage
- ae2:crafting_accelerator
- ae2:crafting_monitor
- ae2:crafting_unit
---

# CPU de crafteo

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="crafting_accelerator" scale="4" />

  <BlockImage id="crafting_monitor" scale="4" />

  <BlockImage id="crafting_unit" scale="4" />
</Row>

Las CPU administran las solicitudes de crafteo y guardan los ingredientes intermedios durante las tareas de varios pasos. Determinan el tamaño de las tareas y, hasta cierto punto, la velocidad. Consulta [autocrafteo](../ae2-mechanics/autocrafting.md) para más información.

Cada CPU de crafteo atiende 1 solicitud o tarea. Si quieres pedir a la vez un procesador de cálculo y 256 de piedra lisa, necesitas 2 CPU multibloque.

Puedes configurarlas para atender solicitudes de jugadores, de sistemas automáticos —buses de exportación e interfaces— o de ambos.

Haz click derecho para abrir el estado del crafteo y consultar el progreso de la tarea de esa CPU.

## Ajustes

* Puedes configurarla para solicitudes de jugadores, de sistemas automáticos —como <ItemLink id="export_bus" /> con <ItemLink id="crafting_card" />— o de ambos.

## Construcción

Las CPU son estructuras multibloque con forma de prisma rectangular sólido y sin huecos. Se componen de varios tipos de bloque.

Cada CPU necesita al menos 1 almacenamiento de crafteo. De hecho, una CPU mínima consiste en un único almacenamiento de crafteo de 1k.

# Unidad de crafteo

<BlockImage id="crafting_unit" scale="4" />

**Opcional:** las unidades de crafteo rellenan espacios para completar el prisma si no tienes suficientes bloques de otros tipos. También son un ingrediente básico de los demás componentes.

<RecipeFor id="crafting_unit" />

<a name="crafting-storage"></a>

# Almacenamiento de crafteo

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="4k_crafting_storage" scale="4" />

  <BlockImage id="16k_crafting_storage" scale="4" />

  <BlockImage id="64k_crafting_storage" scale="4" />

  <BlockImage id="256k_crafting_storage" scale="4" />
</Row>

**Obligatorio:** el almacenamiento de crafteo existe en 1k, 4k, 16k, 64k y 256k. Guarda los ingredientes y productos intermedios: las tareas con más ingredientes necesitan mayor capacidad o más bloques de almacenamiento.

<Column>
  <Row>
    <RecipeFor id="1k_crafting_storage" />

    <RecipeFor id="4k_crafting_storage" />

    <RecipeFor id="16k_crafting_storage" />
  </Row>

  <Row>
    <RecipeFor id="64k_crafting_storage" />

    <RecipeFor id="256k_crafting_storage" />
  </Row>
</Column>

# Unidad de coprocesamiento de crafteo

<BlockImage id="crafting_accelerator" scale="4" />

**Opcional:** los coprocesadores permiten enviar lotes desde los <ItemLink id="pattern_provider" /> con más frecuencia, para abastecer máquinas rápidas. Por ejemplo, un proveedor rodeado de <ItemLink id="molecular_assembler" /> puede repartir ingredientes entre ellos más rápido de lo que un solo ensamblador los procesa.

<RecipeFor id="crafting_accelerator" />

# Monitor de crafteo

<BlockImage id="crafting_monitor" scale="4" />

**Opcional:** el monitor muestra la tarea actual de la CPU. Puedes cambiar el color de su pantalla con un <ItemLink id="color_applicator" />.

<RecipeFor id="crafting_monitor" />
