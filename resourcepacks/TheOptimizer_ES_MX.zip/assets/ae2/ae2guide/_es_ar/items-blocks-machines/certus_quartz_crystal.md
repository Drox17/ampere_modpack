---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de cuarzo Certus
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# Cristal de cuarzo Certus

<ItemImage id="certus_quartz_crystal" scale="4" />

*«Los cristales de cuarzo Certus tienen la peculiar capacidad de aceptar grandes cantidades de energía en su estructura cristalina».*

Uno de los ingredientes principales de los bloques, [dispositivos](../ae2-mechanics/devices.md) y objetos de AE2. Se cultiva en [drusas de cuarzo Certus](../ae2-mechanics/certus-growth.md).

## Algunas recetas alternativas

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />
