---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Manipulador de entropía
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# Manipulador de entropía

<ItemImage id="entropy_manipulator" scale="4" />

El manipulador de entropía calienta con click derecho y enfría con Shift + click derecho. Tiene funciones limitadas: evaporar o congelar agua, solidificar lava en obsidiana, convertir troncos en carbón vegetal y fundir roca en piedra directamente en el mundo.

Si el bloque no tiene una interacción específica, actúa como un encendedor.

Se recarga en un <ItemLink id="charger" />.

## Receta

<RecipeFor id="entropy_manipulator" />
