---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de Fluix
  icon: fluix_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_crystal
---

# Cristal de Fluix

<ItemImage id="fluix_crystal" scale="4" />

*«Los cristales de Fluix pueden absorber y convertir energía de una forma a otra, y son la base de toda la tecnología Matter Energy».*

Uno de los ingredientes principales de los bloques, [dispositivos](../ae2-mechanics/devices.md) y objetos de AE2. Se obtiene lanzando al agua cuarzo del Nether, redstone y <ItemLink id="charged_certus_quartz_crystal" />.

Puedes [automatizarlo](../example-setups/throw-in-water-automation.md) con un <ItemLink id="formation_plane" /> y un <ItemLink id="annihilation_plane" />.

## Recetas

<Row>
  <Recipe id="transform/fluix_crystals" />

  <Recipe id="transform/fluix_crystal" />

  <Recipe id="misc/deconstruction_fluix_block" />
</Row>
