---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Receptor de energía
  icon: energy_acceptor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_acceptor
---

# Receptor de energía

<Row gap="20">
<BlockImage id="energy_acceptor" scale="8" /> 

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
</GameScene>
</Row>

El receptor convierte la energía de otros mods tecnológicos a AE, la unidad interna de [energía](../ae2-mechanics/energy.md) de AE2. El <ItemLink id="controller" /> también puede hacerlo, pero sus caras son valiosas: suele convenir usar un receptor.

Las equivalencias de Forge Energy y TechReborn Energy son:

* 2 FE = 1 AE (Forge)
* 1 E = 2 AE (Fabric)

La velocidad de conversión depende por completo de cuánta energía AE puede almacenar la red, como explica [esta página](../ae2-mechanics/energy.md).

## Variantes

Tiene 2 variantes: bloque normal y plana, como [componente de cable](../ae2-mechanics/cable-subparts.md), para crear instalaciones compactas.

Puedes alternar ambas variantes en una cuadrícula de crafteo.

## Receta

<RecipeFor id="energy_acceptor" />

<RecipeFor id="cable_energy_acceptor" />