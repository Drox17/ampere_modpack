---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Núcleos de formación y aniquilación
  icon: formation_core
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:formation_core
- ae2:annihilation_core
---

# Núcleos de formación y aniquilación

<Row>
  <ItemImage id="formation_core" scale="4" />

  <ItemImage id="annihilation_core" scale="4" />
</Row>

Ingredientes principales de los [dispositivos](../ae2-mechanics/devices.md) de entrada y salida. Combinan <ItemLink id="fluix_crystal" /> y un [procesador lógico](processors.md) para permitir el manejo de objetos, bloques y fluidos. No tienen una función propia: son componentes de crafteo.

## Recetas

<RecipeFor id="formation_core" />

<RecipeFor id="annihilation_core" />
