---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cables
  icon: fluix_glass_cable
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:white_glass_cable
- ae2:orange_glass_cable
- ae2:magenta_glass_cable
- ae2:light_blue_glass_cable
- ae2:yellow_glass_cable
- ae2:lime_glass_cable
- ae2:pink_glass_cable
- ae2:gray_glass_cable
- ae2:light_gray_glass_cable
- ae2:cyan_glass_cable
- ae2:purple_glass_cable
- ae2:blue_glass_cable
- ae2:brown_glass_cable
- ae2:green_glass_cable
- ae2:red_glass_cable
- ae2:black_glass_cable
- ae2:fluix_glass_cable
- ae2:white_covered_cable
- ae2:orange_covered_cable
- ae2:magenta_covered_cable
- ae2:light_blue_covered_cable
- ae2:yellow_covered_cable
- ae2:lime_covered_cable
- ae2:pink_covered_cable
- ae2:gray_covered_cable
- ae2:light_gray_covered_cable
- ae2:cyan_covered_cable
- ae2:purple_covered_cable
- ae2:blue_covered_cable
- ae2:brown_covered_cable
- ae2:green_covered_cable
- ae2:red_covered_cable
- ae2:black_covered_cable
- ae2:fluix_covered_cable
- ae2:white_covered_dense_cable
- ae2:orange_covered_dense_cable
- ae2:magenta_covered_dense_cable
- ae2:light_blue_covered_dense_cable
- ae2:yellow_covered_dense_cable
- ae2:lime_covered_dense_cable
- ae2:pink_covered_dense_cable
- ae2:gray_covered_dense_cable
- ae2:light_gray_covered_dense_cable
- ae2:cyan_covered_dense_cable
- ae2:purple_covered_dense_cable
- ae2:blue_covered_dense_cable
- ae2:brown_covered_dense_cable
- ae2:green_covered_dense_cable
- ae2:red_covered_dense_cable
- ae2:black_covered_dense_cable
- ae2:fluix_covered_dense_cable
- ae2:white_smart_cable
- ae2:orange_smart_cable
- ae2:magenta_smart_cable
- ae2:light_blue_smart_cable
- ae2:yellow_smart_cable
- ae2:lime_smart_cable
- ae2:pink_smart_cable
- ae2:gray_smart_cable
- ae2:light_gray_smart_cable
- ae2:cyan_smart_cable
- ae2:purple_smart_cable
- ae2:blue_smart_cable
- ae2:brown_smart_cable
- ae2:green_smart_cable
- ae2:red_smart_cable
- ae2:black_smart_cable
- ae2:fluix_smart_cable
- ae2:white_smart_dense_cable
- ae2:orange_smart_dense_cable
- ae2:magenta_smart_dense_cable
- ae2:light_blue_smart_dense_cable
- ae2:yellow_smart_dense_cable
- ae2:lime_smart_dense_cable
- ae2:pink_smart_dense_cable
- ae2:gray_smart_dense_cable
- ae2:light_gray_smart_dense_cable
- ae2:cyan_smart_dense_cable
- ae2:purple_smart_dense_cable
- ae2:blue_smart_dense_cable
- ae2:brown_smart_dense_cable
- ae2:green_smart_dense_cable
- ae2:red_smart_dense_cable
- ae2:black_smart_dense_cable
- ae2:fluix_smart_dense_cable
---

# Cables

<GameScene zoom="3" background="transparent">
  <ImportStructure src="../assets/assemblies/cables.snbt" />
  <IsometricCamera yaw="180" pitch="30" />
</GameScene>

Las máquinas ME adyacentes también forman redes, pero los cables son el medio principal para extenderlas por áreas grandes.

Los cables de distintos colores no se conectan entre sí, lo que ayuda a distribuir mejor los [canales](../ae2-mechanics/channels.md). Su color también determina el de las terminales conectadas: no tienen por qué ser todas moradas. Los cables Fluix se conectan a cualquier color.

**LOS CANALES NO TIENEN NADA QUE VER CON EL COLOR DEL CABLE.**

## Una aclaración importante

**Si estás empezando con AE2 y sus canales, usa cables inteligentes normales o densos siempre que puedas. Muestran sus rutas y ayudan a entender su funcionamiento.**

## Otra aclaración

**No son tuberías de objetos, fluidos, energía ni similares.** No tienen inventario interno y los proveedores o máquinas no introducen contenido en ellos. Solo unen los [dispositivos](../ae2-mechanics/devices.md) de AE2 para formar una red.

## Cable ME de vidrio

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/fluix_glass_cable.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

El <ItemLink id="fluix_glass_cable" /> es el más sencillo. Transmite energía y hasta 8 [canales](../ae2-mechanics/channels.md). Tiene 17 colores: Fluix, el predeterminado, y los que se obtienen con los 16 tintes.

Para teñir cables, rodea un tinte con 8 cables del mismo tipo. Pueden ser de distintos colores, pero todos deben ser de vidrio, inteligentes, etc. También puedes pintarlos ya colocados con cualquier pincel compatible con Forge.

Combina un cable teñido con un cubo de agua en la cuadrícula de crafteo para quitarle el color.

Recubre el cable con lana para obtener <ItemLink id="fluix_covered_cable" />, o craftea <ItemLink id="fluix_smart_cable" /> para entender mejor qué ocurre con tus [canales](../ae2-mechanics/channels.md).

<RecipeFor id="fluix_glass_cable" />

<RecipeFor id="blue_glass_cable" />

## Cable ME recubierto

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

El cable recubierto no aporta ventajas funcionales frente al <ItemLink id="fluix_glass_cable" />: es una alternativa estética si prefieres ese acabado.

Se tiñe igual que el <ItemLink id="fluix_glass_cable" />. Combina cuatro <ItemLink id="fluix_covered_cable" /> con redstone y piedra luminosa para obtener <ItemLink id="fluix_covered_dense_cable" />.

<Recipe id="network/cables/covered_fluix" />

<RecipeFor id="blue_covered_cable" />

<a name="dense-cable"></a>

## Cable ME denso

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Admite 32 canales frente a los 8 del cable normal, pero no admite buses ni paneles. Para colocarlos, primero deriva hacia un cable menor, como <ItemLink id="fluix_glass_cable" /> o <ItemLink id="fluix_smart_cable" />.

Los cables densos modifican ligeramente la regla del camino más corto: los canales buscan primero el cable denso más cercano y después el recorrido más corto por él hasta el controlador.

<Recipe id="network/cables/dense_covered_fluix" />

<RecipeFor id="blue_covered_dense_cable" />

<a name="smart-cable"></a>

## Cable ME inteligente

<Row>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
</Row>

Su aspecto recuerda al <ItemLink id="fluix_covered_cable" />, pero muestran el uso de canales mediante líneas luminosas sobre la franja negra. En un cable inteligente normal, los primeros cuatro canales aparecen en su color y los cuatro siguientes en blanco. En uno denso, cada línea representa 4 canales.

En redes con un <ItemLink id="controller" />, las líneas muestran la ruta exacta de los canales.

En una red ad hoc muestran los canales ocupados de toda la red, no los que pasan por ese cable concreto.

También se tiñen como el <ItemLink id="fluix_glass_cable" />.

<Recipe id="network/cables/smart_fluix" />

<Recipe id="network/cables/dense_smart_fluix" />

<RecipeFor id="blue_smart_cable" />
