---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Controlador ME
  icon: controller
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:controller
---

# Controlador ME

<BlockImage id="controller" p:state="online" scale="8" />

El controlador dirige las rutas de la [red ME](../ae2-mechanics/me-network-connections.md). Sin él, la red es ad hoc y solo admite un total de 8 [dispositivos](../ae2-mechanics/devices.md) que consuman canal.

Una [red ME](../ae2-mechanics/me-network-connections.md) no puede tener 2 controladores separados.

Ofrece 32 [canales](../ae2-mechanics/channels.md) por cara.

Cada bloque de controlador necesita 6 AE/t y almacena 8000 AE. Las redes grandes pueden necesitar almacenamiento de energía adicional; consulta [energía](../ae2-mechanics/energy.md).

La estructura multibloque del controlador admite bastante libertad de diseño.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controllers.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Pero debe cumplir estas reglas:

1. Todos los bloques de controlador de una [red ME](../ae2-mechanics/me-network-connections.md) deben estar unidos; de lo contrario, se ponen rojos.
2. La estructura debe caber dentro de 7x7x7; si no, se pone roja.
3. Un bloque de controlador solo puede tener 2 vecinos opuestos en 1 eje como máximo. Si incumple esta regla, se desactiva y se pone rojo.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controller_rules.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Si cumple las reglas y recibe energía, brilla y cambia de color.

Haz click derecho sobre el controlador para abrir la misma interfaz que ofrece la <ItemLink id="network_tool" />.

## Receta

<RecipeFor id="controller" />
