---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de cuarzo Certus cargado
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# Cristal de cuarzo Certus cargado

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

Un <ItemLink id="certus_quartz_crystal" /> procesado en un <ItemLink id="charger" />. Se usa para producir <ItemLink id="fluix_crystal" /> y [drusas de cuarzo Certus](../items-blocks-machines/budding_certus.md).

## Receta

<RecipeFor id="charged_certus_quartz_crystal" />
