---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Mesa de trabajo de celdas
  icon: cell_workbench
  position: 310
categories:
- machines
item_ids:
- ae2:cell_workbench
---

# Mesa de trabajo de celdas

<BlockImage id="cell_workbench" scale="8" />

La mesa de trabajo de celdas permite configurar [celdas de almacenamiento](storage_cells.md) y <ItemLink id="view_cell" />.

Puedes añadir [tarjetas de mejora](upgrade_cards.md) y configurar «particiones» que filtren lo que la celda admite.

Puedes arrastrar objetos y fluidos de JEI/REI a las ranuras aunque no los tengas.

Haz click derecho con un contenedor de fluidos, como un cubo o tanque, para filtrar su contenido en vez del propio contenedor.

## Ajustes

La mesa tiene varios botones en la esquina superior izquierda:

* Particionar la celda según su contenido actual.
* Borrar su partición.
* Conservar la configuración al retirar la celda para copiarla a otras.

## Receta

<RecipeFor id="cell_workbench" />
