---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fachadas
  icon: facade
  icon_nbt: '{item: "minecraft:stone"}'
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:facade
---

# Fachadas

Las fachadas dan un aspecto más limpio a tu base. Cubren ambos tamaños de cable y se crean a partir de muchos tipos de bloques.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/facades_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Pueden cubrir todas las caras del cable dejando sobresalir sus conexiones y [componentes](../ae2-mechanics/cable-subparts.md).

<GameScene zoom="6"  interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Úsalas con ingenio para decorar la base o crear bloques con una textura distinta en cada cara.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_3.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Ocultar las fachadas

Las fachadas se ocultan mientras sostienes una <a href="network_tool.md">herramienta de red</a> en cualquiera de las manos.

Mientras estén ocultas puedes interactuar con los bloques detrás de ellas sin retirarlas.

## Receta

Rodea el bloque cuya textura quieras usar con 4 <ItemLink id="cable_anchor" />.

![Receta de fachada](../assets/diagrams/facade_recipe.png)
