---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Polvo de ender
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# Polvo de ender

<ItemImage id="ender_dust" scale="4" />

Una perla de ender triturada en un <ItemLink id="inscriber" />. Sirve para producir <ItemLink id="wireless_booster" /> y pares de <ItemLink id="quantum_entangled_singularity" />.

## Receta

<RecipeFor id="ender_dust" />
