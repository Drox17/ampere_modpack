---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Guía
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# Guía

<ItemImage id="guide" scale="8" />

### La guía que estás leyendo: toda la orientación que necesitas sobre AE2.

* Abre la barra lateral izquierda para consultar el índice.
* Muchas páginas tienen escenas interactivas. Si ves los botones ![Más](../assets/diagrams/plus.png) y ![Menos](../assets/diagrams/minus.png) de zoom, puedes mover la cámara: arrastra con click izquierdo para girarla y con click derecho para desplazarla.

## Receta

<RecipeFor id="guide" />
