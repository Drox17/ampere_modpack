---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Plantilla de herrería de Fluix
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# Plantilla de herrería de Fluix

A diferencia de la plantilla vanilla, esta se puede crear desde cero.

Necesaria para las [herramientas de Fluix](fluix_tools.md).

## Receta

<RecipeFor id="fluix_upgrade_smithing_template" />