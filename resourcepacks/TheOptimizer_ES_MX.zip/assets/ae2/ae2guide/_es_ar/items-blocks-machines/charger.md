---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cargador
  icon: charger
  position: 310
categories:
- machines
item_ids:
- ae2:charger
---

# Cargador

<BlockImage id="charger" scale="8" />

El cargador recarga herramientas compatibles y <ItemLink id="certus_quartz_crystal" />.

Recibe energía por arriba o abajo mediante [cables](cables.md) de AE2 o cables de energía de otros mods. Acepta AE o Forge Energy (FE). Admite inserción y extracción de objetos por cualquier cara, pero solo deja extraer los resultados: no necesitas filtros para evitar retirar cuarzo sin cargar. Puedes girarlo con una <ItemLink id="certus_quartz_wrench" /> para facilitar la automatización.

Permite crear <ItemLink id="charged_certus_quartz_crystal" /> a partir de <ItemLink id="certus_quartz_crystal" />, y una <ItemLink id="meteorite_compass" /> a partir de una <ItemLink id="minecraft:compass" />.

Para alimentarlo a mano, coloca una <ItemLink id="crank" /> arriba o abajo y haz click derecho hasta cargar el objeto.

También es el bloque de trabajo del aldeano de AE2.

## Automatización sencilla

Por ejemplo, al poder girarlo puedes semiautomatizarlo así:

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/charger_hopper.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Receta

<RecipeFor id="charger" />
