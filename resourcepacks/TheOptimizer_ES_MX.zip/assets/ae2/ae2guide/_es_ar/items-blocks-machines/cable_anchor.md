---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Anclaje para cables
  icon: cable_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:cable_anchor
---

# Anclaje para cables

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/cable_anchor.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Son pequeñas puntas decorativas montadas en cables. Sirven para impedir conexiones, trepar por los cables o darles la apariencia de estar sujetos a las paredes. También se usan para craftear <ItemLink id="facade" />.

Los anclajes impiden las conexiones por la cara donde están colocados.

Puedes trepar por ellos como por una escalera de mano.

## Receta

<RecipeFor id="cable_anchor" />
