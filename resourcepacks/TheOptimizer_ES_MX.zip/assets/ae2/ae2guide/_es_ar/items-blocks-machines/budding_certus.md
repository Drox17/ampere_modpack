---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Drusas de cuarzo Certus
  icon: flawless_budding_quartz
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:flawless_budding_quartz
- ae2:flawed_budding_quartz
- ae2:chipped_budding_quartz
- ae2:damaged_budding_quartz
- ae2:small_quartz_bud
- ae2:medium_quartz_bud
- ae2:large_quartz_bud
- ae2:quartz_cluster
---

# Drusas de cuarzo Certus

Consulta también [crecimiento del cuarzo Certus](../ae2-mechanics/certus-growth.md).

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Los brotes de cuarzo Certus crecen en las drusas de los [meteoritos](../ae2-mechanics/meteorites.md), como ocurre con la amatista. Hay 4 estados: perfecta, imperfecta, astillada y dañada. Puedes identificarlos fácilmente con HWYLA, Jade, The One Probe o la pantalla F3.

En las drusas imperfectas, astilladas y dañadas, cada etapa de crecimiento de un brote puede deteriorar la drusa un nivel hasta convertirla en un <ItemLink id="quartz_block" /> normal.

Las drusas perfectas no se deterioran al crecer los brotes: son una fuente infinita.

Al romper una drusa con un pico normal, se deteriora 1 nivel. Toque de seda lo evita, excepto en las perfectas. **No puedes recoger y trasladar una drusa perfecta con un pico.** Usa el [almacenamiento espacial](../ae2-mechanics/spatial-io.md) para cortar y pegar el espacio que la contiene.

## Recetas

Puedes crear drusas imperfectas, astilladas y dañadas lanzando al agua la del nivel anterior, o un <ItemLink id="quartz_block" />, con uno o más <ItemLink id="charged_certus_quartz_crystal" />.

Las drusas perfectas no se pueden craftear: solo se encuentran en el mundo.

<Row>
  <RecipeFor id="damaged_budding_quartz" />

  <RecipeFor id="chipped_budding_quartz" />

  <RecipeFor id="flawed_budding_quartz" />
</Row>
