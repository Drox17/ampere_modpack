---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Plano de aniquilación ME
  icon: annihilation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:annihilation_plane
---

# Plano de aniquilación ME

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/annihilation_plane.snbt" />
</GameScene>

El plano de aniquilación rompe bloques y recoge objetos. Funciona como un <ItemLink id="import_bus" />: introduce contenido en el [almacenamiento de red](../ae2-mechanics/import-export-storage.md). Los objetos deben tocar su cara para ser recogidos; no recoge en un área.

Admite todos los encantamientos de pico, así que puedes darle niveles absurdos de Fortuna y [automatizar el procesamiento de minerales](../example-setups/ore-fortuner.md) si tu modpack lo permite. Toque de seda hace lo esperado, Eficiencia reduce la energía necesaria para romper bloques e Irrompibilidad da una probabilidad de no gastar energía.

Son [componentes de cable](../ae2-mechanics/cable-subparts.md).

**RECUERDA PERMITIR LOS FAKE PLAYERS EN LOS CHUNKS QUE HAYAS RECLAMADO.**

## Filtrado

El plano solo rompe un bloque o recoge un objeto si puede guardar el resultado en su red. Para filtrarlo, *limita qué puede almacenar esa red*, normalmente mediante una [subred](../ae2-mechanics/subnetworks.md). Puedes [particionar](cell_workbench.md) un <ItemLink id="storage_bus" /> o una [celda](../items-blocks-machines/storage_cells.md) para conseguirlo.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/annihilation_filtering.snbt" />

  <DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
Filtrado para lo que suelta el bloque que quieres romper.
  </DiamondAnnotation>

  <DiamondAnnotation pos=".5 0.5 2.5" color="#00ff00">
Particionada para lo que suelta el bloque que quieres romper.
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

El filtro depende de *los objetos que suelta el bloque*. Para filtrar <ItemLink id="minecraft:amethyst_cluster" />, por ejemplo, necesitas Toque de seda. Sin él, las etapas previas no sueltan nada y el plano las rompe igualmente: la red siempre puede almacenar «nada».

## Receta

<RecipeFor id="annihilation_plane" />
