---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bloques decorativos de Fluix
  icon: fluix_stairs
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_stairs
- ae2:fluix_wall
- ae2:fluix_slab
---

# Bloques decorativos de Fluix

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/decorative_fluix.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Puedes convertir <ItemLink id="fluix_block" /> en bloques decorativos mediante crafteo y cortapiedras.

## Recetas

<Row>
  <RecipeFor id="fluix_stairs" />

  <RecipeFor id="fluix_wall" />

  <RecipeFor id="fluix_slab" />
</Row>
