---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Polvo de cuarzo Certus
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# Polvo de cuarzo Certus

<ItemImage id="certus_quartz_dust" scale="4" />

Un <ItemLink id="certus_quartz_crystal" /> triturado en un <ItemLink id="inscriber" />. Se utiliza para producir varios materiales y componentes de AE2.

## Receta

<RecipeFor id="certus_quartz_dust" />
