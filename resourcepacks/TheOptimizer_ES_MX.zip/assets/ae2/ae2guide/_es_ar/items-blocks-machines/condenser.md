---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Condensador de materia
  icon: condenser
  position: 310
categories:
- machines
item_ids:
- ae2:condenser
---

# Condensador de materia

<BlockImage id="condenser" scale="8" />

El condensador de materia sirve como papelera o para crear <ItemLink id="matter_ball" /> y [singularidades](singularities.md). Admite cualquier objeto, fluido u otro material que pueda almacenar una celda.

## Ajustes y recetas

* **Papelera:** destruye todo lo que recibe.
* **Bolas de materia:** convierte lo que recibe en <ItemLink id="matter_ball" />. Requiere un componente de almacenamiento en la ranura superior. Cada bola consume 256 objetos o cubos: un <ItemLink id="cell_component_1k" />, con capacidad para 8192 bits, es más que suficiente.
* **Singularidades:** convierte lo que recibe en [singularidades](singularities.md). También requiere un componente de almacenamiento arriba. Cada singularidad consume 256,000 objetos o cubos: un <ItemLink id="cell_component_64k" />, con 524,288 bits, es más que suficiente.

En los dos modos que producen recursos, el condensador *puede* atascarse. No aceptará más entradas si se llenan tanto la reserva de energía como la salida de objetos.

## Receta

<RecipeFor id="condenser" />
