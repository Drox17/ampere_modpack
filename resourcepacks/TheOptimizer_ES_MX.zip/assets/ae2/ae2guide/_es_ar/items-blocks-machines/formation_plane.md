---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Plano de formación ME
  icon: formation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:formation_plane
---

# Plano de formación ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/formation_plane.snbt" />
</GameScene>

El plano de formación coloca bloques y suelta objetos. Actúa como un <ItemLink id="storage_bus" /> de solo inserción: coloca o suelta lo que los [dispositivos](../ae2-mechanics/devices.md), como <ItemLink id="import_bus" /> e <ItemLink id="interface" />, intentan introducir en el [almacenamiento de red](../ae2-mechanics/import-export-storage.md).

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/formation_plane_demonstration.snbt" />
  <IsometricCamera yaw="255" pitch="30" />
</GameScene>

Este [dispositivo](../ae2-mechanics/devices.md) aprovecha la misma mecánica que los buses de almacenamiento de las [subredes tipo tubería](../example-setups/pipe-subnet.md). Puede sustituirlos para colocar bloques o soltar objetos en vez de transportarlos a otro inventario.

Son [componentes de cable](../ae2-mechanics/cable-subparts.md).

**RECUERDA PERMITIR LOS FAKE PLAYERS EN LOS CHUNKS QUE HAYAS RECLAMADO.**

## Filtrado

Por defecto coloca o suelta cualquier objeto. Los filtros forman una lista de permitidos que limita qué puede colocar.

Puedes arrastrar objetos y fluidos de JEI/REI a las ranuras aunque no los tengas.

Haz click derecho con un contenedor de fluidos, como un cubo o tanque, para filtrar su contenido en vez del propio contenedor.

## Prioridad

Ajusta la prioridad con la llave de la esquina superior derecha. Los objetos entrantes buscan primero el almacenamiento de mayor prioridad.

## Ajustes

* Puedes configurarlo para colocar bloques en el mundo o soltar objetos.

## Mejoras

El plano de formación admite estas [mejoras](upgrade_cards.md):

* <ItemLink id="capacity_card" />: añade ranuras de filtro.
* <ItemLink id="fuzzy_card" />: filtra por daño y/o ignora el NBT.
* <ItemLink id="inverter_card" />: convierte la lista de permitidos en una de excluidos.

## Receta

<RecipeFor id="formation_plane" />
