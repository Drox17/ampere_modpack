---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Herramientas de Fluix
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# Herramientas de Fluix

<Row>
  <ItemImage id="fluix_axe" scale="4" />

  <ItemImage id="fluix_hoe" scale="4" />

  <ItemImage id="fluix_shovel" scale="4" />

  <ItemImage id="fluix_pickaxe" scale="4" />

  <ItemImage id="fluix_sword" scale="4" />
</Row>

Las herramientas de [Fluix](fluix_crystal.md) se parecen a las de hierro, pero tienen el triple de durabilidad y algo más de daño y velocidad de minado.

Todas actúan como si tuvieran al menos Fortuna o Saqueo 1: muy útil antes de conseguir una mesa de encantamientos.

Necesitarás una <ItemLink id="fluix_upgrade_smithing_template" />.

## Recetas

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />

    <RecipeFor id="fluix_hoe" />

    <RecipeFor id="fluix_shovel" />
  </Row>

  <Row>
    <RecipeFor id="fluix_pickaxe" />

    <RecipeFor id="fluix_sword" />
  </Row>
</Column>
