---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Celdas de energía
  icon: energy_cell
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_cell
- ae2:dense_energy_cell
- ae2:creative_energy_cell
---

# Celdas de energía

<Row gap="20">
  <BlockImage id="energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="8" />
</Row>

Las celdas aumentan el almacenamiento de [energía](../ae2-mechanics/energy.md). Una pequeña reserva absorbe picos al insertar o extraer muchos objetos. Una reserva mayor permite funcionar sin generación, por ejemplo de noche con paneles solares, o cubrir el consumo instantáneo del [almacenamiento espacial](../ae2-mechanics/spatial-io.md).

## Barras de carga

<Row>
<BlockImage id="energy_cell" scale="4" p:fullness="0" />
<BlockImage id="energy_cell" scale="4" p:fullness="1" />
<BlockImage id="energy_cell" scale="4" p:fullness="2" />
<BlockImage id="energy_cell" scale="4" p:fullness="3" />
<BlockImage id="energy_cell" scale="4" p:fullness="4" />
</Row>

Las barras laterales indican la carga:

* 0: menos del 25 %.
* 1: entre el 25 % y el 50 %.
* 2: entre el 50 % y el 75 %.
* 3: entre el 75 % y el 99 %.
* 4: más del 99 %.

## Tipos de celdas

* La <ItemLink id="energy_cell" /> almacena 200k AE. Una suele bastar para los picos de consumo habituales.
* La <ItemLink id="dense_energy_cell" /> almacena 1.6M AE: sirve para funcionar con energía acumulada o cubrir el gran consumo instantáneo de instalaciones de [almacenamiento espacial](../ae2-mechanics/spatial-io.md).
* La <ItemLink id="creative_energy_cell" /> es un objeto creativo para pruebas que proporciona ¡ENERGÍAAA ILIMITADAAA!, o algo así.

## Recetas

<Row>
  <RecipeFor id="energy_cell" />

  <RecipeFor id="dense_energy_cell" />
</Row>
