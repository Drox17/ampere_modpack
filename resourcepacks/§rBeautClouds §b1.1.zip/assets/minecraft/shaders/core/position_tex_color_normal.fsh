#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;

in vec2 texCoord0;
in float vertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

const float FOG_START_DIST = 200.0;
const float FOG_END_DIST   = 300.0;

void main() {
    vec4 tex = texture(Sampler0, texCoord0);

    if (tex.a < 0.1) {
        discard;
    }

    float fog = smoothstep(FOG_START_DIST, FOG_END_DIST, vertexDistance);

    fragColor = vec4(tex.rgb * vertexColor.rgb * ColorModulator.rgb, vertexColor.a * tex.a * (1.0 - fog));
}
