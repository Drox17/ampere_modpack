#version 150

#moj_import <fog.glsl>

uniform vec4 ColorModulator;
uniform vec4 FogColor;
uniform float FogStart;
uniform float FogEnd;

in float vertexDistance;
in float cloudAlpha;

out vec4 fragColor;

void main() {
    float width = FogEnd - FogStart;
    float fade = linear_fog_fade(vertexDistance, FogStart, FogStart + width * 4.0) * FogColor.a;

    fragColor = vec4(ColorModulator.rgb, cloudAlpha * fade);
}
