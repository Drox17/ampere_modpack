#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out float vertexDistance;
out float cloudAlpha;

const float CLOUD_SCALE_Y = 1.3;
const float ALPHA_NEAR    = 0.95;
const float ALPHA_FAR     = 0.08;

void main() {
    vec3 scaledPos = vec3(Position.x, Position.y * CLOUD_SCALE_Y, Position.z);
    gl_Position = ProjMat * ModelViewMat * vec4(scaledPos, 1.0);

    vec4 pos = ModelViewMat * vec4(Position.x, 0.0, Position.z, 1.0);
    vertexDistance = length(pos.xyz);

    float cameraY = -dot(ModelViewMat[1].xyz, ModelViewMat[3].xyz);
    float camAbove = clamp(cameraY / (4.0 * CLOUD_SCALE_Y), 0.0, 1.0);

    float yval = clamp(Position.y / 4.0, 0.0, 1.0);

    bool flatLayer = Position.y < 0.01 && max(Color.r, max(Color.g, Color.b)) > 0.95;

    float alphaBottom = mix(ALPHA_NEAR, ALPHA_FAR, camAbove);
    float alphaTop    = mix(ALPHA_FAR, ALPHA_NEAR, camAbove);

    cloudAlpha = (flatLayer ? ALPHA_NEAR : mix(alphaBottom, alphaTop, yval)) * Color.a;
}
