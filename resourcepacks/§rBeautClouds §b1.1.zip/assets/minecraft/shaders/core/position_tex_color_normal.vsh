#version 150

in vec3 Position;
in vec2 UV0;
in vec4 Color;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 texCoord0;
out float vertexDistance;
out vec4 vertexColor;

const float CLOUD_SCALE_Y = 1.3;
const float ALPHA_NEAR    = 0.95;
const float ALPHA_FAR     = 0.08;

void main() {
    int corner = gl_VertexID % 4;

    float yval;
    if (Normal.y > 0.5) {
        yval = 1.0;
    } else if (Normal.y < -0.5) {
        yval = 0.0;
    } else if (abs(Normal.x) > 0.5) {
        yval = (corner == 1 || corner == 2) ? 1.0 : 0.0;
    } else {
        yval = (corner == 0 || corner == 1) ? 1.0 : 0.0;
    }

    float slabY = Position.y - 4.0 * yval;
    float scaledY = Position.y + 4.0 * yval * (CLOUD_SCALE_Y - 1.0);

    vec4 pos = ModelViewMat * vec4(Position.x, scaledY, Position.z, 1.0);
    gl_Position = ProjMat * pos;

    texCoord0 = UV0;
    vertexDistance = length(pos.xyz);

    float brightness = Normal.y > 0.5 ? 1.0 : (Normal.y < -0.5 ? 0.7 : (abs(Normal.x) > 0.5 ? 0.9 : 0.8));

    float slabOffset = dot(ModelViewMat[1].xyz, ModelViewMat[3].xyz);
    float baseHeight = slabY + slabOffset;
    float camAbove = clamp(-baseHeight / (4.0 * CLOUD_SCALE_Y), 0.0, 1.0);

    float alphaBottom = mix(ALPHA_NEAR, ALPHA_FAR, camAbove);
    float alphaTop    = mix(ALPHA_FAR, ALPHA_NEAR, camAbove);
    float alpha = Normal.y < -0.5 ? ALPHA_NEAR : mix(alphaBottom, alphaTop, yval);

    vertexColor = vec4(min(Color.rgb / brightness, 1.0), alpha);
}
