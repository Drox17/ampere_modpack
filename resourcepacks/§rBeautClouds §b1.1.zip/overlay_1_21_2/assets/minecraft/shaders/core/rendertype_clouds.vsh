#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ModelOffset;
uniform int FogShape;
uniform vec4 ColorModulator;

out float vertexDistance;
out vec4 vertexColor;
out vec3 cellPos;
flat out float flatLayer;

const float CLOUD_SCALE_Y = 1.3;
const float ALPHA_NEAR    = 0.95;
const float ALPHA_FAR     = 0.08;

void main() {
    vec3 pos = vec3(Position.x, Position.y * CLOUD_SCALE_Y, Position.z) + ModelOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexDistance = fog_distance(pos, FogShape);
    cellPos = Position;

    float camAbove = clamp(-ModelOffset.y / (4.0 * CLOUD_SCALE_Y), 0.0, 1.0);
    float yval = clamp(Position.y / 4.0, 0.0, 1.0);

    flatLayer = (Position.y < 0.01 && max(Color.r, max(Color.g, Color.b)) > 0.95) ? 1.0 : 0.0;

    float alphaBottom = mix(ALPHA_NEAR, ALPHA_FAR, camAbove);
    float alphaTop    = mix(ALPHA_FAR, ALPHA_NEAR, camAbove);
    float alpha = flatLayer > 0.5 ? ALPHA_NEAR : mix(alphaBottom, alphaTop, yval);

    vertexColor = vec4(Color.rgb * ColorModulator.rgb, alpha);
}
