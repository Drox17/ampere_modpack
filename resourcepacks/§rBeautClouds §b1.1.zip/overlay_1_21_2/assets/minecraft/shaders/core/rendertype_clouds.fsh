#version 150

#moj_import <minecraft:fog.glsl>

uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec3 cellPos;
flat in float flatLayer;

out vec4 fragColor;

const bool  UNSHADE_FACES     = true;
const float BRIGHTNESS_BOTTOM = 0.7;
const float BRIGHTNESS_X      = 0.9;
const float BRIGHTNESS_Z      = 0.8;

void main() {
    vec4 color = vertexColor;

    if (UNSHADE_FACES) {
        vec3 n = abs(cross(dFdx(cellPos), dFdy(cellPos)));
        float shade = 1.0;

        if (max(n.x, max(n.y, n.z)) > 0.0) {
            if (n.y > n.x && n.y > n.z) {
                shade = (cellPos.y > 2.0 || flatLayer > 0.5) ? 1.0 : BRIGHTNESS_BOTTOM;
            } else if (n.x > n.z) {
                shade = BRIGHTNESS_X;
            } else {
                shade = BRIGHTNESS_Z;
            }
        }

        color.rgb = min(color.rgb / shade, vec3(1.0));
    }

    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
